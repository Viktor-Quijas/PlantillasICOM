#include "Sucursal.h"

Sucursal::Sucursal(int id) {
	SetId(id);
	this->nombre = " ";
	this->direccion = " ";
	this->telefono = " ";
	this->horario = " ";
}

Sucursal::Sucursal(string nombre, int id) {
	SetId(id);
	SetNombre(nombre);
	this->direccion = " ";
	this->telefono = " ";
	this->horario = " ";
}

Sucursal::Sucursal(string nombre, string direccion, string telefono, string horario, int id) {
	SetId(id);
	SetNombre(nombre);
	SetDireccion(direccion);
	SetTelefono(telefono);
	SetHorario(horario);
}

Sucursal::~Sucursal() {}

		/*Setters*/

void Sucursal::SetId(int id) { this->id = id; }
void Sucursal::SetNombre(string nombre) { this->nombre = nombre; }
void Sucursal::SetDireccion(string direccion) { this->direccion = direccion; }
void Sucursal::SetTelefono(string telefono) { this->telefono = telefono; }
void Sucursal::SetHorario(string horario) { this->horario = horario; }

		/*Getters*/

int Sucursal::GetId() { return id; }
string Sucursal::GetNombre() { return nombre; }
string Sucursal::GetDireccion() { return direccion; }
string Sucursal::GetHorario() { return horario; }
string Sucursal::GetTelefono() { return telefono; }