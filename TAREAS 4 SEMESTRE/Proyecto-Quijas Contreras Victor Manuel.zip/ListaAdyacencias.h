#pragma once
#include "NodoArista.h"
class ListaAdyacencias
{
public:
	NodoArista* h;
	int tamanio;

	void InsertarArista(int destino, int peso);
	NodoArista* BuscarDestino(int destino);
	NodoArista* BuscarPeso(int peso);
	void MostrarNodoArista(NodoArista* referencia);
	void EliminarArista(int destino);
	void EliminarLista();
	void Sort();

	NodoArista* MenorPeso(NodoArista* ref);

	ListaAdyacencias();
	~ListaAdyacencias();
};