#include "ListaAdyacencias.h"

ListaAdyacencias::ListaAdyacencias() {
	this->h = nullptr;
	this->tamanio = 0;
}

ListaAdyacencias::~ListaAdyacencias() {
	EliminarLista();
}

		/*Operaciones*/

void ListaAdyacencias::InsertarArista(int destino, int peso) {
	NodoArista* aux = new NodoArista(destino, peso, h);
	h = aux;
	tamanio++;
	Sort();
}

NodoArista* ListaAdyacencias::BuscarDestino(int destino) {
	NodoArista* temp = h;

	while (temp && temp->destino != destino)
		temp = temp->sig;

	if (temp && temp->destino == destino)
		return temp;
	else
		return nullptr;
}

NodoArista* ListaAdyacencias::BuscarPeso(int peso) {
	NodoArista* temp = h;

	while (temp && temp->peso != peso)
		temp = temp->sig;

	if (temp && temp->peso == peso)
		return temp;
	else
		return nullptr;
}

void ListaAdyacencias::MostrarNodoArista(NodoArista* referencia) {
	if (!referencia) {
		cout << endl << "Algo salio mal, la referencia a mostrar no existe." << "\n\n";
		return;
	}

	cout << endl << "\t\t" << "+-----------------+" << endl;
	cout << "\t\t" << "Adyacente a: " << referencia->destino << endl;
	cout << "\t\t" << "Peso: " << referencia->peso << endl;
	cout << "\t\t" << "+-----------------+" << endl;
	return;
}

void ListaAdyacencias::EliminarArista(int destino) {
	NodoArista* act = h;
	NodoArista* ant = nullptr;

	while (act && act->destino != destino) {
		ant = act;
		act = act->sig;
	}

	if (!act) {
		cout << endl << "El elemento '" << destino << "' no se encuentra en esta lista." << "\n\n";
		return;
	}

	if (act == h) {
		h = act->sig;
		delete act;
		tamanio--;
	}
	else {
		ant->sig = act->sig;
		delete act;
		tamanio--;
	}
	return;
}

void ListaAdyacencias::EliminarLista() {
	NodoArista* act = h;
	NodoArista* ant = nullptr;

	while (act) {
		ant = act;
		act = act->sig;
		delete ant;
	}
	h = nullptr;
	return;
}

void ListaAdyacencias::Sort() {
	if (!h)
		return;

	int pesoTemp;
	int destinoTemp;
	bool swap;
	int i, n = 0;

	NodoArista* act = h->sig;
	NodoArista* ant = h;

	while (n < tamanio) {
		swap = false;				//Inicializa las banderas para
		i = 0;							//la sig vuelta
		while (i < tamanio - 1 - n) {
			if (ant->peso > act->peso) {	//Swap info
				pesoTemp = act->peso;
				destinoTemp = act->destino;
				act->peso = ant->peso;
				act->destino = ant->destino;
				ant->peso = pesoTemp;
				ant->destino = destinoTemp;
				swap = true;
			}
			ant = act;			//Avanza por la lista
			act = act->sig;
			i++;
		}
		act = h->sig;		//n^2 pipi
		ant = h;
		n++;
		if (!swap)		
			break;
	}
}

NodoArista* ListaAdyacencias::MenorPeso(NodoArista* ref) {
	if (!ref)
		return h;
	return ref->sig;
}