#include "OpGrafo.h"

OpGrafo::OpGrafo() {
	this->h = nullptr;
	this->t = nullptr;
	this->tamanio = 0;
}

OpGrafo::~OpGrafo() {
	EliminarGrafo();
}

void OpGrafo::InsertarVertice(Sucursal* info) { //Inserta al final
	NodoVertice* aux = new NodoVertice(info);
	if (!h) {
		h = aux;
		t = aux;
		tamanio++;
		return;
	}
	t->sig = aux;
	t = aux;
	tamanio++;
	return;
}

void OpGrafo::InsertarArista(int sucursalA, int sucursalB, int peso) {
	if (peso < 1) {
		cout << "No se permiten pesos menores a 1." << endl;
		return;
	}
	if (sucursalA == sucursalB) {
		cout << "Grafo simple, no se permiten lazos (vertice apuntandose asi mismo)." << endl;
		return;
	} 
	else if (BuscarArista(sucursalA, sucursalB)) {
		cout << "Grafo simple, no se permiten multiples aristas." << endl;
		return;
	}
	
	NodoVertice* aux = h; 
	NodoVertice* verA = nullptr;	//Vertice A
	NodoVertice* verB = nullptr;	//Vertice B

	while (aux) {
		if (aux->info->GetId() == sucursalA) 		//Buscar a los
			verA = aux;								//vertices a y b
		if (aux->info->GetId() == sucursalB)
			verB = aux;
		aux = aux->sig;
	}
	
	if (!verA || !verB) {		//No encontr� a los nodos.
		cout << "Vertices inexistentes." << endl;
		return;
	}

	//Opera:
	verA->adyacencias->InsertarArista(verB->info->GetId(), peso);
	verB->adyacencias->InsertarArista(verA->info->GetId(), peso);

	return;
}

NodoArista* OpGrafo::BuscarArista(int idSucursal, int destino) {
	NodoVertice* auxVer = BuscarVertice(idSucursal);

	if (!auxVer)
		return nullptr;

	NodoArista* auxAri = auxVer->adyacencias->BuscarDestino(destino);

	if (!auxAri)
		return nullptr;
	else
		return auxAri;
}

NodoVertice* OpGrafo::BuscarVertice(int idSucursal) {
	if (idSucursal < 1)
		return nullptr;

	NodoVertice* aux = h;
	while (aux && aux->info->GetId() != idSucursal)
		aux = aux->sig;

	if (!aux)
		return nullptr;

	return aux;
}

void OpGrafo::EliminarArista(int idSucursal, int destino) {
	NodoVertice* aux = BuscarVertice(idSucursal);

	if (!aux)
		return;
	aux->adyacencias->EliminarArista(destino);
	aux = BuscarVertice(destino);
	if (!aux)
		return;
	aux->adyacencias->EliminarArista(idSucursal);
}

void OpGrafo::EliminarVertice(int idSucursal) {
	NodoVertice* act = h;
	NodoVertice* ant = nullptr;
	int destino;

	while (act->sig && idSucursal != act->info->GetId()) {
		ant = act;
		act = act->sig;
	}

	if (!act)		//Si no se encontr� el vertice.
		return;

	NodoArista* auxAri = act->adyacencias->h;
	NodoVertice* temp;

	while (auxAri) {
		destino = auxAri->destino;
		auxAri = auxAri->sig;
		EliminarArista(destino, idSucursal);
	}

	if (h == act)
		h = act->sig;
	else if (t == act) {
		t = ant;
		t->sig = nullptr;
	} else
		ant->sig = act->sig;

	delete act;
	tamanio--;

	return;
}

void OpGrafo::EliminarGrafo() {
	NodoVertice* act = h;
	NodoVertice* ant = nullptr;

	while (act) {
		ant = act;
		act = act->sig;
		delete ant;
		tamanio--;
	}
	h = nullptr;
	t = nullptr;
}

void OpGrafo::ImprimirAristas(ListaAdyacencias* l) {
	if (!l)
		return;
	NodoArista* aux = l->h;
	while (aux) {
		l->MostrarNodoArista(aux);
		aux = aux->sig;
	}
}

void OpGrafo::ImprimirArista(int SucursalA, int SucursalB) {
	NodoVertice* auxVer = BuscarVertice(SucursalA);

	if (auxVer)
		auxVer->adyacencias->MostrarNodoArista(BuscarArista(SucursalA, SucursalB));
}

void OpGrafo::ImprimirVertice(NodoVertice* vertice) {
	if (!vertice)
		return;

	cout << endl << "+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+" << endl;
	cout << "\t\t\t" << "   ID " << vertice->info->GetId() << endl;
	cout << "+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+" << endl;
	cout << "Sucursal: " << vertice->info->GetNombre() << endl;
	cout << "Direccion: " << vertice->info->GetDireccion() << endl;
	cout << "Telefono: " << vertice->info->GetTelefono() << endl;
	cout << "Horario: " << vertice->info->GetHorario() << "\n\n";
	if (vertice->adyacencias->h) {
		cout << "\t\t" << "~~~ Vertices adyacentes ~~~" << endl;
		ImprimirAristas(vertice->adyacencias);
	}
	else {
		cout << "\t\t" << "~~~ Vertices adyacentes ~~~" << endl;
		cout << endl << "\t\t" << "+-----------------+" << endl;
		cout << "\t\t" << "  Sin vertices " << endl;
		cout << "\t\t" << "      adyacentes!" << endl;
		cout << "\t\t" << "+-----------------+" << endl;
	}
	cout << "+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+" << "\n\n";
}

void OpGrafo::ImprimirVertices(NodoVertice* vertice) {
	if (!vertice)
		return;

	while (vertice) {
		ImprimirVertice(vertice);
		vertice = vertice->sig;
	}

}

void OpGrafo::CopiarInfo(NodoVertice* SucursalA, NodoVertice* SucursalB) {
	Sucursal* aux = new Sucursal(SucursalB->info->GetId());

	aux->SetNombre(SucursalB->info->GetNombre());
	aux->SetDireccion(SucursalB->info->GetDireccion());
	aux->SetHorario(SucursalB->info->GetHorario());
	aux->SetTelefono(SucursalB->info->GetTelefono());

	if (SucursalA->info)
		delete SucursalA->info;
	SucursalA->info = aux;
	return;
}

NodoVertice* OpGrafo::AlgoritmoPrim() {
	if (!h) {
		cout << "Grafo vacio." << endl;
		return nullptr;
	}

	NodoVertice* auxVer = h;			//Indice que visita vertices del grafo orig.
	NodoVertice* crearVer = nullptr;	//Ptr aux para la creacion de nodos del sub�rbol.
	NodoVertice* indArb = nullptr;		//Indice que recorre el sub arbol.
	NodoVertice* raizArbol = nullptr;	//Cabeza del nuevo sub�rbol.
	NodoVertice* ultimoArb = nullptr;	//Cola del sub�rbol.
	NodoVertice* guardarVer = nullptr;	//Ptr aux, conserva un nodo del sub�rbol para insertar aristas.
	NodoArista* ariMenor = nullptr;		//Contiene el nodo arista de menor peso de un vertice.	
	int tamanioArbol = 0;				//Tama�o del sub�rbol.
	int peso;							//Conserva un peso.					
	int destino;							//Conserva un puntero.

	while (tamanioArbol < tamanio) {
		auxVer->visitado = true;

		if (!raizArbol) {						//Primer bloque.
			raizArbol = new NodoVertice();		//Insertar al inicio del subarbol,
			CopiarInfo(raizArbol, auxVer);		//cuando no existe uno creado.
			ultimoArb = raizArbol;				
			tamanioArbol++;									
		}
		else {
			crearVer = new NodoVertice();		// O inserta al final.
			CopiarInfo(crearVer, auxVer);
			ultimoArb->sig = crearVer;
			ultimoArb = crearVer;
			tamanioArbol++;
		}

		indArb = raizArbol;
		peso = INT_MAX;
		destino = -1;
		
		while (indArb && tamanioArbol < tamanio) {			//Segundo bloque.
			auxVer = BuscarVertice(indArb->info->GetId());	
			ariMenor = nullptr;
			while (true) {
				ariMenor = auxVer->adyacencias->MenorPeso(ariMenor);
				if (ariMenor && ariMenor->peso <= peso && !BuscarVertice(ariMenor->destino)->visitado) {
					peso = ariMenor->peso;
					destino = ariMenor->destino;
					guardarVer = indArb;
					break;
				}
				else if (ariMenor && ariMenor->sig) {
					continue;
				}
				else if (ariMenor && !ariMenor->sig || !ariMenor) {
					break;
				}
			}
			indArb = indArb->sig;
		}

		if (tamanioArbol < tamanio && destino == -1) {
			cout << "Grafo no conexo!" << endl;
			return nullptr;
		}
		else if (tamanioArbol < tamanio) {
			guardarVer->adyacencias->InsertarArista(destino, peso);
			auxVer = BuscarVertice(destino);
		}
	}
	return raizArbol;
}

void OpGrafo::ImprimirPrim() {
	if (!h)
		return;

	NodoVertice* act = h;
	NodoVertice* ant = nullptr;
	NodoVertice* MST = AlgoritmoPrim(); //Minimum Spanning Tree

	while (act) {
		act->visitado = false;
		act = act->sig;
	}

	if (!MST)
		return;

	ImprimirVertices(MST);

	act = MST;
	while (act) {
		ant = act;
		act = act->sig;
		delete ant;
	}
	return;
}