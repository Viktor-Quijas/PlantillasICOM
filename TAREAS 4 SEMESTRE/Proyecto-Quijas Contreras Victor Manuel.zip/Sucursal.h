#pragma once
#include <iostream>
#include <string>
using namespace std;

class Sucursal
{
private:
	int id;
	string nombre;
	string direccion;
	string telefono;
	string horario;

public:
	/*Setters*/
	void SetId(int id);
	void SetNombre(string nombre);
	void SetDireccion(string direccion);
	void SetTelefono(string telefono);
	void SetHorario(string horario);

	/*Getters*/
	int GetId();
	string GetNombre();
	string GetDireccion();
	string GetTelefono();
	string GetHorario();

	Sucursal(int id);
	Sucursal(string nombre, int id);
	Sucursal(string nombre, string direccion, string telefono, string horario, int id);
	~Sucursal();
};