#pragma once
#include "NodoVertice.h"
class OpGrafo
{
public:
	NodoVertice* h;
	NodoVertice* t;
	int tamanio;

	void InsertarVertice(Sucursal* info);
	void InsertarArista(int sucursalA, int sucursalB, int peso);
	NodoArista* BuscarArista(int idSucursal, int destino);
	NodoVertice* BuscarVertice(int idSucursal);
	void EliminarArista(int idSucursal, int destino);
	void EliminarVertice(int idSucursal);
	void EliminarGrafo();
	void ImprimirArista(int SucursalA, int SucursalB);
	void ImprimirAristas(ListaAdyacencias* l);
	void ImprimirVertice(NodoVertice* vertice);
	void ImprimirVertices(NodoVertice* vertice);

	void CopiarInfo(NodoVertice* a, NodoVertice* b);
	NodoVertice* AlgoritmoPrim();
	void ImprimirPrim();

	OpGrafo();
	~OpGrafo();
};