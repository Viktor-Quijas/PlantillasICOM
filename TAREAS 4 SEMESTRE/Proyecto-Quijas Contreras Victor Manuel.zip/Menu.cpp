#include "Menu.h"

Menu::Menu() {
	this->id = 0;
	this->nombre = " ";
	this->direccion = " ";
	this->telefono = "0000000000";
	this->horario = " ";
	this->eleccion = 0;
	this->a = 0;
	this->b = 0;
	this->peso = 0;
	this->g = new OpGrafo();
}

Menu::~Menu() {
	g->EliminarGrafo();
}

void Menu::ImprimirSuc(Sucursal* nueva) {
	cout << endl << "+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+" << endl;
	cout << "\t\t\t" << "   ID " << nueva->GetId() << endl;
	cout << "+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+" << endl;
 	cout << "Nombre de la sucursal: " << nueva->GetNombre() << endl;
	cout << "Direccion: " << nueva->GetDireccion() << endl;
	cout << "Telefono: " << nueva->GetTelefono() << endl;
	cout << "Horario: " << nueva->GetHorario() << endl;
	cout << "+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+" << endl;
}

bool Menu::Confirmacion(int eleccion) { //Parametro controlado.
	switch (eleccion) {
	case 1:			//SalirMenuPrincipal.
		while (true) {
			cout << endl << "Seguro que deseas salir?" << endl;
			cout << "1.Si" << endl;
			cout << "2.No" << endl;
			cout << "-> ";
			cin >> eleccion;

			switch (eleccion) {
			case 1:
				cout << "\n\n" << "Hasta pronto!" << endl;
				system("pause");
				return true;
			case 2:
				return false;
			default:
				cout << "Algo salio mal, ingrese un digito valido." << "\n\n";
				break;
			}
		}
		break;
	case 2:			//Entrada al editor.
		while (true) {
			cout << endl << "Deseas editar algun campo?" << endl;
			cout << "1.Si" << endl;
			cout << "2.No" << endl;
			cout << "-> ";
			cin >> eleccion;

			switch (eleccion) {
			case 1:
				return true;
			case 2:
				return false;
			default:
				cout << "Algo salio mal, ingrese un digito valido." << "\n\n";
				break;
			}
		}
		break;
	case 3:			//Salir del editor.
		while (true) {
			cout << endl << "Deseas editar algo mas?" << endl;
			cout << "1.Si" << endl;
			cout << "2.No" << endl;
			cout << "-> ";
			cin >> eleccion;
			
			switch (eleccion) {
			case 1:
				return true;
			case 2:
				return false;
			default:
				cout << "Algo salio mal, ingrese un digito valido." << "\n\n";
				break;
			}
		}
		break;
	case 4:			//Eliminar grafo.
		while (true) {
			cout << endl << "Deseas eliminar el grafo?" << endl;
			cout << "1.Si" << endl;
			cout << "2.No" << endl;
			cout << "-> ";
			cin >> eleccion;

			switch (eleccion) {
			case 1:
				return true;
			case 2:
				return false;
			default:
				cout << "Algo salio mal, ingrese un digito valido." << "\n\n";
				break;
			}
		}
		break;
	case 5:
		while (true) {
			cout << "Ingresar grafo predefinido?" << endl;
			cout << "1.Si" << endl;
			cout << "2.No" << endl;
			cout << "-> ";
			cin >> eleccion;

			switch (eleccion) {
			case 1:
				return true;
			case 2:
				return false;
			default:
				cout << endl << "Algo salio mal, ingrese un digito valido." << "\n\n";
				break;
			}
		}
		break;
	}
	
}

Sucursal* Menu::CrearSuc() {
	system("cls");
	cout << "~~~ Formato de la sucursal ~~~" << endl;
	cout << "Nombre de la sucursal: (ejem. Farmacia Santa Teresita)" << endl;
	cout << "-> ";
	cin.ignore();
	getline(cin, nombre);
	cout << "Direccion: (ejem. Calle Juaquin Angulo 44 int B)" << endl;
	cout << "-> ";
	getline(cin, direccion);
	cout << "Telefono: " << endl;
	cout << "-> ";
	getline(cin, telefono);
	cout << "Horario: (ejem. Lun-Vie de 9:00 AM a 6:00 PM y Sab de 10:00 AM a 4:00 PM)" << endl;
	cout << "-> ";
	getline(cin, horario);

	id++; //Genera una nueva id
	
	Sucursal* nueva = new Sucursal(nombre, direccion, telefono, horario, id);

	ImprimirSuc(nueva);
 
	if (Confirmacion(2))
		Editar(nueva);
	
	return nueva;
}

void Menu::Editar(Sucursal* nueva) {
	while (true) {
		system("cls");
		ImprimirSuc(nueva);

		cout << "Seleccione lo que va a editar:" << endl;
		cout << "1.Nombre de la sucursal." << endl;
		cout << "2.Direccion." << endl;
		cout << "3.Telefono." << endl;
		cout << "4.Horario." << endl;
		cout << "-> ";
		cin >> eleccion;

		switch (eleccion) {
		case 1:
			cout << "Ingrese el nuevo nombre: (ejem. Farmacia Santa Teresita)" << endl;
			cout << "-> ";
			cin.ignore();
			getline(cin, nombre);
			nueva->SetNombre(nombre);
			break;
		case 2:
			cout << "Ingrese la nueva direccion: (ejem. Calle Juaquin Angulo 44 int B)" << endl;
			cout << "-> ";
			cin.ignore();
			getline(cin, direccion);
			nueva->SetDireccion(direccion);
			break;
		case 3:
			cout << "Ingrese el nuevo telefono:" << endl;
			cout << "-> ";
			cin.ignore();
			getline(cin, telefono);
			nueva->SetTelefono(telefono);
			break;
		case 4:
			cout << "Ingrese el nuevo horario: (ejem. Lun-Vie de 9:00 AM a 6:00 PM)" << endl;
			cout << "-> ";
			cin.ignore();
			getline(cin, horario);
			nueva->SetHorario(horario);
			break;
		default:
			cout << "Algo salio mal, ingrese un digito valido." << endl;
			system("pause");
			break;
		}

		ImprimirSuc(nueva);
		if (Confirmacion(3))
			Editar(nueva);
			
		return;
	}
}

void Menu::MenuPrincipal() {
	InsertAutomaticOwO();
	while (true) {
		system("cls");
		cout << "\t" << "---  Paqueterias El Valle  ---" << "\n\n";
		cout << "Ingrese el digito de la op que va a realizar." << "\n\n";
		cout << "~~~ Op Vertices ~~~" << endl;
		cout << "1.Insertar sucursal." << endl;
		cout << "2.Buscar sucursal." << endl;
		cout << "3.Mostrar mapa de las sucursales." << endl;
		cout << "4.Eliminar sucursal." << "\n\n";
		cout << "~~~ Op Arista ~~~" << endl;
		cout << "5.Insertar conexion." << endl;
		cout << "6.Buscar conexion." << endl;
		cout << "7.Mostrar conexiones de una sucursal." << endl;
		cout << "8.Eliminar conexion." << "\n\n";
		cout << "9.Mostrar el camino mas corto entre sucursales (Prim)." << endl;
		cout << "10.Eliminar mapa." << endl;
		cout << "0.Salir" << endl;
		cout << "-> ";
		cin >> eleccion;

		switch (eleccion) {
		case 1:
			MenuInsertar(1);
			system("pause");
			break;
		case 2:
			MenuBuscar(1);
			system("pause");
			break;
		case 3:
			MenuMostrar(1);
			system("pause");
			break;
		case 4:
			MenuEliminar(1);
			system("pause");
			break;
		case 5:
			MenuInsertar(2);
			system("pause");
			break;
		case 6:
			MenuBuscar(2);
			system("pause");
			break;
		case 7:
			MenuMostrar(2);
			system("pause");
			break;
		case 8:
			MenuEliminar(2);
			system("pause");
			break;
		case 9:
			system("cls");
			g->ImprimirPrim();
			system("pause");
			break;
		case 10:
			MenuEliminar(3);
			break;
		case 0:
			if (Confirmacion(1))
				return;
			break;
		default:
			cout << "Algo salio mal, ingrese un digito valido." << endl;
			system("pause");
			break;
		}
	}
}

void Menu::MenuInsertar(int eleccion) {
	system("cls");
	switch (eleccion) {
	case 1:
		g->InsertarVertice(CrearSuc());
		break;
	case 2:
		g->ImprimirVertices(g->h);
		cout << "Ingrese los IDs de las sucursales adyacentes y la distancia del camino (peso):" << endl;
		cout << "a = ";
		cin >> a;
		cout << "b = ";
		cin >> b;
		cout << "peso = ";
		cin >> peso;
		
		g->InsertarArista(a, b, peso);
		break;
	}
}

void Menu::MenuBuscar(int eleccion) {
	system("cls");
	if (!g->h) {
		cout << "Mapa vacio." << endl;
		return;
	}
	switch (eleccion) {
	case 1:
		cout << "Ingrese el ID de la sucursal:" << endl;
		cout << "-> ";
		cin >> a;
		g->ImprimirVertice(g->BuscarVertice(a));
		break;
	case 2:
		cout << "Ingresa los IDs de las sucursales adyacentes" << endl;
		cout << "a = ";
		cin >> a;
		cout << "b = ";
		cin >> b;

		g->ImprimirArista(a, b);
		break;
	}
}

void Menu::MenuMostrar(int eleccion) {
	system("cls");
	if (!g->h) {
		cout << "Mapa vacio." << endl;
		return;
	}
	switch (eleccion) {
	case 1:
		g->ImprimirVertices(g->h);
		break;
	case 2: {
		NodoVertice* aux;
		cout << "Ingrese el ID de la conexion:" << endl;
		cin >> a;
		aux = g->BuscarVertice(a);
		g->ImprimirAristas(aux->adyacencias);
		break;
		}
	}
}

void Menu::MenuEliminar(int eleccion) {
	system("cls");
	if (!g->h) {
		cout << "Mapa vacio." << endl;
		return;
	}
	switch (eleccion) {
	case 1:
		g->ImprimirVertices(g->h);
		cout << "Ingrese el ID de la sucursal a eliminar: " << endl;
		cout << "-> ";
		cin >> a;
		g->EliminarVertice(a);
		break;
	case 2:
		g->ImprimirVertices(g->h);
		cout << "Ingrese los IDs de las sucursales adyacentes: " << endl;
		cout << "a = ";
		cin >> a;
		cout << "b = ";
		cin >> b;
		g->EliminarArista(a, b);
		break;
	case 3:
		if (Confirmacion(4)) {
			g->EliminarGrafo();
			id = 0;
		}
		break;
	}
}

void Menu::InsertAutomaticOwO() {

	if (!Confirmacion(5))
		return;

	id = 10;
	Sucursal* aux;

	nombre = "Paqueterias Valle Matriz San Andres";
	direccion = "Av Chamizal 853";
	telefono = "800 911 9999";
	horario = "Lun a Vie de 7:30 AM a 8:00 PM y Sab de 8:00 AM a 6:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 1);
	g->InsertarVertice(aux);

	nombre = "Paqueterias Valle La 74";
	direccion = "C Ramon Lopez Velarde 375";
	telefono = "33 9173 8569";
	horario = "Lun a Vie de 7:30 AM a 7:00 PM y Sab de 9:00 AM a 5:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 2);
	g->InsertarVertice(aux);

	nombre = "Paqueterias Valle Felipe Angeles";
	direccion = "Av Francisco Javier Mina 1928";
	telefono = "33 3643 2834";
	horario = "Lun a Vie de 9:00 AM a 7:00 PM y Sab de 10:00 AM a 6:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 3);
	g->InsertarVertice(aux);

	nombre = "Paqueterias Valle Forum Tlaquepaque";
	direccion = "Av Rio Nilo 2003 int 12";
	telefono = "33 3698 7845";
	horario = "Lun a Vie de 7:30 AM a 6:00 PM y Sab de 9:00 AM a 6:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 4);
	g->InsertarVertice(aux);

	nombre = "Paqueterias Valle Parque San Rafael";
	direccion = "Av San Jacinto 452 local B y C";
	telefono = "800 911 9999";
	horario = "Lun a Vie de 7:30 AM a 7:00 PM y Sab de 9:00 AM a 6:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 5);
	g->InsertarVertice(aux);

	nombre = "Paqueterias Valle San Juan Bosco";
	direccion = "Av Republica 1554";
	telefono = "800 911 9999";
	horario = "Lun a Vie de 7:30 AM a 7:00 PM y Sab de 9:00 AM a 5:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 6);
	g->InsertarVertice(aux);

	nombre = "Paqueterias Valle Parque La Expenal";
	direccion = "Av Francisco Javier Mina 1450";
	telefono = "33 3669 3333";
	horario = "Lun a Vie de 7:30 AM a 7:00 PM y Sab de 10:00 AM a 6:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 7);
	g->InsertarVertice(aux);

	nombre = "Paqueterias Valle Tlaquepaque Centro";
	direccion = "C Prisiliano Sanchez 71-C";
	telefono = "33 2300 0470";
	horario = "Lun a Vie de 7:30 AM a 7:00 PM y Sab de 9:00 AM a 3:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 8);
	g->InsertarVertice(aux);

	nombre = "Paqueterias Valle CUCEI";
	direccion = "Blvd. Gral. Marcelino Garc�a Barragan 1627";
	telefono = "33 4737 4884";
	horario = "Lun a Vie de 6:30 AM a 6:00 PM y Sab de 9:00 AM a 2:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 9);
	g->InsertarVertice(aux);

	nombre = "Paqueterias Valle Obregon";
	direccion = "C Alvaro Obregon 162-C";
	telefono = "33 3618 1817";
	horario = "Lun a Vie de 9:30 AM a 7:00 PM y Sab de 10:00 AM a 3:00 PM";

	aux = new Sucursal(nombre, direccion, telefono, horario, 10);
	g->InsertarVertice(aux);

	//Aristas para la matriz
	g->InsertarArista(1, 2, 1);
	g->InsertarArista(1, 3, 5);
	g->InsertarArista(1, 4, 4);
	g->InsertarArista(1, 5, 2);
	g->InsertarArista(1, 6, 4);
	g->InsertarArista(1, 7, 3);
	g->InsertarArista(1, 8, 6);
	g->InsertarArista(1, 9, 5);
	g->InsertarArista(1, 10, 7);

	//Aristas para los demas en orden owo
	g->InsertarArista(2, 3, 2);
	g->InsertarArista(2, 5, 4);

	g->InsertarArista(3, 5, 3);
	g->InsertarArista(3, 6, 4);

	g->InsertarArista(4, 9, 1);
	g->InsertarArista(4, 8, 3);

	g->InsertarArista(5, 8, 4);
	g->InsertarArista(5, 4, 3);

	g->InsertarArista(6, 7, 2);
	g->InsertarArista(6, 9, 7);

	g->InsertarArista(7, 2, 3);
	g->InsertarArista(7, 10, 4);

	g->InsertarArista(8, 9, 4);
	//g->InsertarArista(8, 6, 10);

	//g->InsertarArista(9, 2, 4);
	//g->InsertarArista(9, 3, 5);

	g->InsertarArista(10, 4, 7);
	//g->InsertarArista(10, 8, 11);
}