#pragma once
#include <iostream>
using namespace std;
class NodoArista
{
public:
	int destino;
	int peso;
	NodoArista* sig;

	NodoArista();
	NodoArista(int destino, int peso);
	NodoArista(int destino, int peso, NodoArista* sig);
	~NodoArista();
};