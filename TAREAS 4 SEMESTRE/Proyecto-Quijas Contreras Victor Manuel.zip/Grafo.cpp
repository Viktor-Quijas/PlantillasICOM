#include <iostream>
#include "Menu.h"
int main()
{
	Menu* menu;
	menu = new Menu();
	menu->MenuPrincipal();
	return 0;
}