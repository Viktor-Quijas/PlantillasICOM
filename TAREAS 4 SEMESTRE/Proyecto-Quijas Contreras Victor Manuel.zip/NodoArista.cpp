#include "NodoArista.h"

NodoArista::NodoArista() {
	this->destino = ' ';
	this->peso = 0;
	this->sig = nullptr;
}

NodoArista::NodoArista(int destino, int peso) {
	this->destino = destino;
	this->peso = peso;
	this->sig = nullptr;
}

NodoArista::NodoArista(int destino, int peso, NodoArista* sig) {
	this->destino = destino;
	this->peso = peso;
	this->sig = sig;
}

NodoArista::~NodoArista() {}