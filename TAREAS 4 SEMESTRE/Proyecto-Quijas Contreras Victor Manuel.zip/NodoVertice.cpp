#include "NodoVertice.h"

NodoVertice::NodoVertice() {
	this->info = nullptr;
	this->adyacencias = new ListaAdyacencias();
	this->sig = nullptr;
	this->visitado = false;
}

NodoVertice::NodoVertice(Sucursal* info) {
	this->info = info;
	this->adyacencias = new ListaAdyacencias();
	this->sig = nullptr;
	this->visitado = false;
}


NodoVertice::NodoVertice(Sucursal* info, NodoVertice* sig) {
	this->info = info;
	this->adyacencias = new ListaAdyacencias();
	this->sig = sig;
	this->visitado = false;
}

NodoVertice::~NodoVertice() {
	delete adyacencias;
	delete info;
}