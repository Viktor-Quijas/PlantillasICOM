#pragma once
#include "NodoArista.h"
#include "Sucursal.h"
#include "ListaAdyacencias.h"
class NodoVertice
{
public:
	Sucursal* info;
	ListaAdyacencias* adyacencias;
	NodoVertice* sig;

	bool visitado;

	NodoVertice(Sucursal* info);
	NodoVertice(Sucursal* info, NodoVertice* sig);
	NodoVertice();
	~NodoVertice();
};