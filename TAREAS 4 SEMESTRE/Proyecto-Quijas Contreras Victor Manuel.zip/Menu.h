#pragma once
#include "OpGrafo.h"
#include "Sucursal.h"
class Menu
{
private:
	int id;
	string nombre;
	string direccion;
	string telefono;
	string horario;

	int eleccion;
	OpGrafo* g;

	int a, b, peso;

public:
	void MenuPrincipal();
	Sucursal* CrearSuc();
	void Editar(Sucursal* nueva);
	bool Confirmacion(int eleccion);
	void ImprimirSuc(Sucursal* nueva);
	void MenuInsertar(int eleccion);
	void MenuBuscar(int eleccion);
	void MenuMostrar(int eleccion);
	void MenuEliminar(int eleccion);

	void InsertAutomaticOwO();

	Menu();
	~Menu();
};

/*
Matriz San Andr�s - 1
la 74 - 2
Felipe Angeles - 3
Forum Tlaquepaque - 4
San Rafael - 5
San Juan Bosco - 6
La expenal - 7
Tlaquepaque Centro - 8
CUCEI - 9
Obregon - 10
*/