#ifndef NODO_H
#define NODO_H
#include "Dato.h"

class Nodo
{
    public:
        Dato* info;
        Nodo* sig;
        Nodo* ant;

        Nodo(Dato* info);
        Nodo(Dato* info, Nodo* sig, Nodo* ant);
        Nodo();
        ~Nodo();

    protected:

    private:
};

#endif // NODO_H


