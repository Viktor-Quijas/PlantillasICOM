// Quijas Contreras Victor Manuel       11/10/2025
#include <iostream>
#include "Menu.h"

using namespace std;

int main()
{
    Menu menu;
    menu.MenuPrincipal();
    return 0;
}


/*
Conclusiones:

    Los ordenamientos son una herramienta muy efectiva para facilitar operaciones
    de busqueda en las TDA listas con la implementaci�n de la busqueda binaria. Cada tipo
    de ordenamiento incrementa en su complejidad como lo hace con su eficiencia, mejora
    sus casos y se vuelven algoritmos m�s estables. Fue una actividad algo estresante para
    los ordenamientos m�s complejos como el quicksort pero fue tambi�n divertido e interesante
    ver la aplicaci�n de estos.
*/
