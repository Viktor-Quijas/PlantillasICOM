#include "Lista.h"
#include <cctype>

Lista::Lista()
{
    cabeza = nullptr;
    cola = nullptr;
}

Lista::~Lista()
{
    EliminarTodo();
}

        /*Funciones de insertar*/

void Lista::InsertInicio(Dato* info){
    Nodo* aux;
    aux = new Nodo(info,cabeza,nullptr);

    if (!aux){
        cout << "Error en insercion, memoria no asignada." << endl;
        return;
    }

    if (Vacia()){
        cola = aux;
        cabeza = aux;
    } else {
        cabeza->ant = aux;
        cabeza = aux;
    }
    cout << "Dato insertado al inicio!" << endl;
    return;
}

void Lista::InsertFinal(Dato* info){
    Nodo* aux;
    aux = new Nodo(info,nullptr,cola);

    if (!aux){
        cout << "Error en insercion, memoria no asignada." << endl;
        return;
    }

    if (Vacia()){
        cabeza = aux;
        cola = aux;
    } else {
        cola->sig = aux;
        cola = aux;
    }
    cout << "Dato insertado al final!" << endl;
    return;
}

void Lista::InsertAntes(Dato* info,Nodo* temp){
    Nodo* aux = new Nodo(info,temp,temp->ant);

    if (!aux){
        cout << endl << "Error en insercion, memoria no asignada." << endl;
        return;
    }

    temp->ant->sig = aux;
    temp->ant = aux;
    cout << endl << "Dato insertado correctamente!" << endl;
    return;
}

void Lista::InsertDespues(Dato* info, Nodo* temp){
    Nodo* aux = new Nodo(info,temp->sig,temp);

    if (!aux){
        cout << endl << "Error en insercion, memoria no asignada." << endl;
        return;
    }

        temp->sig->ant = aux;
        temp->sig = aux;
        cout << endl << "Dato insertado correctamente!" << endl;
        return;
}

void Lista::InsertPosicion(Dato* info, int posicion){
    if (Vacia()){
        InsertInicio(info);
        cout << "Dato insertado en la nueva lista!" << endl;
        return;
    } else if (posicion > Tamanio()){
        InsertFinal(info);
        cout << "Dato insertado al final!" << endl;
        return;
    } else if (posicion < 0){
        cout << "Posicion invalida, recuerda usar SOLO enteros positivos." << endl;
        return;
    } else {
        int eleccion;

        cout << "\n\n" << "Deseas insertar antes o despues de la posicion?\n1.Antes\n2.Despues" << endl;
        cout << "-> ";
        cin >> eleccion;

        switch (eleccion){
        case 1:
            if (posicion == 1){
                InsertInicio(info);
                cout << endl << "Dato insertado correctamente!" << endl;
                return;
            } else {
                Nodo* temp = Buscar(posicion);
                InsertAntes(info,temp);
                return;
            }
            break;
        case 2:
            if (posicion == Tamanio()){
                InsertFinal(info);
                cout << endl << "Dato insertado correctamente!" << endl;
                return;
            } else {
                Nodo* temp = Buscar(posicion);
                InsertDespues(info,temp);
                return;
            }
            break;
        default:
            cout << "Ingresa un numero seleccionado en la lista!" << endl << endl;
            InsertPosicion(info, posicion);
            break;
        }
    }
}


        /*Funciones de busqueda*/

bool Lista::Vacia() {return cabeza == nullptr;}

int Lista::Tamanio(){ //Devuelve la cantidad de nodos que existen.
    Nodo* aux = cabeza;
    int tamanio;

    for (tamanio = 0; aux; tamanio++){
        aux = aux->sig;
    }

    return tamanio;
}

Nodo* Lista::Buscar(int posicion){ //Devuelve el nodo en la posici�n indicada.
    if (posicion <= 0 || posicion > Tamanio()){
        cout << "Tu posicion no se encuentra en el rango de la lista, verificala." << endl;
        return nullptr;
    }

    Nodo* aux = cabeza;
    int i = 1;

    while (i != posicion){
        aux = aux->sig;
        i++;
    }
    cout << "Dato encontrado!" << endl;
    return aux;
}

Nodo* Lista::BuscarEntero(int entero){
    Nodo* aux = cabeza;

    while (aux && entero != aux->info->GetEntero()){
        aux = aux->sig;
    }

    if (entero == aux->info->GetEntero()){
        cout << "Dato encontrado!" << endl;
        return aux;
    } else {
        cout << "El Dato no existe en esta lista." << endl;
        return nullptr;
    }
}

Nodo* Lista::Primero(){return cabeza;}

Nodo* Lista::Ultimo(){return cola;}

Nodo* Lista::Anterior(Nodo* referencia){
    if (referencia == Primero()){
        cout << "No existe ningun elemento anterior al primero!" << endl;
        return nullptr;
    }
    if (!referencia){
        cout << "Referencia ingresada apuntando a nulo, revise su referencia." << endl;
        return nullptr;
    }
    return referencia->ant;
}

Nodo* Lista::Siguiente(Nodo* referencia){
    if (referencia == Ultimo()){
        cout << "No existe ningun elemento anterior al ultimo!" << endl;
        return nullptr;
    }
    if (!referencia){
        cout << "Referencia ingresada apuntando a nulo, revise su referencia." << endl;
        return nullptr;
    }
    return referencia->sig;
}

        /*Funciones de mostrar*/

void Lista::MostrarDato(Dato* referencia){
    if (!referencia){
        cout << "Referencia ingresada apuntando a nulo, revise su referencia." << endl;
        return;
    }
    cout << "*********************************************" << endl;
    cout << "Entero: " << referencia->GetEntero() << endl;
    cout << "*********************************************" << "\n\n";
    return;
}

void Lista::MostrarDato(Nodo* referencia){
    if (!referencia){
        cout << "Referencia ingresada apuntando a nulo, revise su referencia." << endl;
        return;
    }
    cout << "*********************************************" << endl;
    cout << "Entero: " << referencia->info->GetEntero() << endl;
    cout << "*********************************************" << "\n\n";
    return;
}

void Lista::MostrarLista(){
    if (!cabeza){
        cout << "Lista vacia!" << endl;
        return;
    }
    Nodo* aux = cabeza;
    int i = 1;
    while (aux){
        cout << "\t\t" << "Posicion: " << i << endl;;
        cout << "*********************************************" << endl;
        cout << "Entero: " << aux->info->GetEntero() << endl;
        cout << "*********************************************" << "\n\n";
        i++;
        aux = aux->sig;
    }
}


void Lista::Eliminar(int posicion){
    Nodo* temp = Buscar(posicion);

    if (!temp){
        cout << "No se encontro el miembro que buscabas eliminar." << endl;
        return;
    }
    if (temp == cabeza){
        temp->sig->ant = nullptr;
        cabeza = temp->sig;
        delete temp;
        cout << "Primer miembro de la lista eliminado!" << endl;
        return;
    }
    if (temp == cola){
        temp->ant->sig = nullptr;
        cola = temp->ant;
        delete temp;
        cout << "Ultimo miembro de la lista eliminado!" << endl;
        return;
    }

    temp->ant->sig = temp->sig;
    temp->sig->ant = temp->ant;
    delete temp;
    cout << "Miembro de la lista eliminado!" << endl;
    return;
}

void Lista::EliminarTodo(){
    Nodo* aux = cabeza;
    Nodo* auxR;
    cabeza = nullptr;
    cola = nullptr;

    while (aux){
        auxR = aux;
        aux = aux->sig;
        delete auxR;
    }

    auxR = nullptr;

    cout << "Lista eliminada con exito!" << endl;
    return;
}

        /*Ordenamientos*/

void Lista::BubbleSort(){
    if (Vacia()){
        cout << "Lista vacia, nada por ordenar" << endl;
        return;
    }
    if (Tamanio() == 1){
        cout << "La lista contiene solo un elemento, ya esta ordenada!" << endl;
        return;
    }
    Nodo* aux = cabeza;
    int i = 0, j = 0, tamanio = Tamanio();

    while (aux && tamanio > i){
        j = 0;
        while (aux && j < tamanio - i){
            if (aux != cola && aux->info->GetEntero() > aux->sig->info->GetEntero()){
                SwapInfo(aux,aux->sig);
            }
            aux = aux->sig;
            j++;
        }
        i++;
        aux = cabeza;
    }
}

void Lista::BetterBubleSort(){
    if (Vacia()){
        cout << "Lista vacia, nada por ordenar" << endl;
        return;
    }
    if (Tamanio() == 1){
        cout << "La lista contiene solo un elemento, ya esta ordenada!" << endl;
        return;
    }
    Nodo* aux = cabeza;
    int i = 0, j = 0;
    int tamanio = Tamanio();
    bool band = true;

    while (aux && tamanio > i && band){
        j = 0;
        band = false;
        while (aux && j < tamanio - i){
            if (aux != cola && aux->info->GetEntero() > aux->sig->info->GetEntero()){
                SwapInfo(aux,aux->sig);
                band = true;
            }
            aux = aux->sig;
            j++;
        }
        i++;
        aux = cabeza;
    }
}

void Lista::InsertionSort(){
    if (Vacia()){
        cout << "Lista vacia, nada por ordenar" << endl;
        return;
    }
    if (Tamanio() == 1){
        cout << "La lista contiene solo un elemento, ya esta ordenada!" << endl;
        return;
    }

    Nodo* recorrer;                     //Recorre la lista comparandose con insertar hasta que encuentra su posicion.
    Nodo* insertar = cabeza->sig;       //Nodo que se va a insertar.
    Nodo* ancla;                        //Ancla, frontera entre los datos ordenados y no ordenados.

    while (insertar){
        ancla = insertar->sig;
        recorrer = insertar->ant;

        while (recorrer && recorrer->info->GetEntero() > insertar->info->GetEntero()){
            recorrer = recorrer->ant;
        }

        InsertarNodo(insertar,recorrer);
        insertar = ancla;
    }
}

void Lista::SelectionSort(){
    if (Vacia()){
        cout << "Lista vacia, nada por ordenar" << endl;
        return;
    }
    if (Tamanio() == 1){
        cout << "La lista contiene solo un elemento, ya esta ordenada!" << endl;
        return;
    }
    Nodo* frontera = cabeza;
    Nodo* seleccionado;

    while (frontera){
        seleccionado = frontera->sig;
        while (seleccionado){
            if (frontera->info->GetEntero() > seleccionado->info->GetEntero()){
                SwapInfo(frontera, seleccionado);
            }
            seleccionado = seleccionado->sig;
        }
        frontera = frontera->sig;
    }
}

void Lista::ShellSort(){
    if (Vacia()){
        cout << "Lista vacia, nada por ordenar" << endl;
        return;
    }
    if (Tamanio() == 1){
        cout << "La lista contiene solo un elemento, ya esta ordenada!" << endl;
        return;
    }

    Nodo* aux;
    Nodo* auxR;
    Nodo* actual;
    int gap = Tamanio() / 2;

    while (gap > 0){
        aux = Buscar(gap + 1);
        auxR = BuscarGapAnterior(aux,gap);

        while (aux){
            actual = aux;
            while (auxR && aux->info->GetEntero() < auxR->info->GetEntero()){
                SwapInfo(aux,auxR);
                aux = auxR;
                auxR = BuscarGapAnterior(aux, gap);
            }
            aux = actual->sig;
            auxR = BuscarGapAnterior(aux,gap);
        }
        gap /= 2;
    }
}


void Lista::QuickSort(){
    if (Vacia()){
        cout << "Lista vacia, nada por ordenar" << endl;
        return;
    }
    if (Tamanio() == 1){
        cout << "La lista contiene solo un elemento, ya esta ordenada!" << endl;
        return;
    }

    QuickSort(cabeza,cola);
}

        /*Funciones complementarias*/

void Lista::SwapInfo(Nodo* a, Nodo* b){
    if (Vacia()){
        cout << "Lista vacia, no hay elementos para hacer intercambios" << endl;
        return;
    }
    if (!cabeza->sig){
        cout << "La lista solo cuenta con un elemento, no se puede hacer un swap!" << endl;
        return;
    }
    if (!a || !b){
        cout << "Alguna de las referencias se encuentra en nulo, no se puede realizar un swap!" << endl;
        return;
    }
    Dato* temp = a->info;
    a->info = b->info;
    b->info = temp;
    return;
}

bool Lista::Ordenado(){
    Nodo* temp = cabeza;
    bool band = true;
    int i;
    for (i = 0; i < Tamanio() && temp != cola; i++){
        if (temp->info->GetEntero() > temp->sig->info->GetEntero()){
            cout << temp->info->GetEntero() << " <-> " << temp->sig->info->GetEntero() << endl;
            band = false;
        }
        temp = temp->sig;
    }
    return band;
}

void Lista::InsertarNodo(Nodo* a, Nodo* b){
    if (Vacia()){
        cout << "Lista vacia, no hay elementos para hacer intercambios" << endl;
        return;
    }
    if (!cabeza->sig){
        cout << "La lista solo cuenta con un elemento!" << endl;
        return;
    }
    if (b && b->sig == a){
        cout << "Ya se encuentra en su posici�n" << endl;
        return;
    }

    /*  Nodo a = Nodo que va a ser removido
        Nodo b = Nodo de referencia donde va a ser insertado*/

            /*Quitar nodo*/
    if (a == cabeza){
        cout << "CABEZA" << endl;
        a->sig->ant = nullptr;
        cabeza = a->sig;
        a->sig = nullptr;
        cout << "cabeza quitada" << endl;
    } else if (a == cola){
        cout << "COLA" << endl;
        a->ant->sig = nullptr;
        cola = a->ant;
        a->ant = nullptr;
        cout << "cola quitada" << endl;
    } else {
        cout << "NODO" << endl;
        a->sig->ant = a->ant;
        a->ant->sig = a->sig;
        a->ant = nullptr;
        a->sig = nullptr;
        cout << "nodo quitado" << endl;
    }

            /*Insertar nodo*/
    if (!b){
        a->sig = cabeza;
        cabeza->ant = a;
        cabeza = a;
    } else {
        a->sig = b->sig;
        a->ant = b;
        if (b->sig){
            b->sig->ant = a;
        }
        if (b == cola){
            cola = a;
        }
        b->sig = a;
    }

    return;
}

Nodo* Lista::BuscarGapAnterior(Nodo* referencia, int n){
    if (!referencia){
        cout << "Referencia apuntando a nulo." << endl;
        return nullptr;
    }

    while (referencia && n > 0){
        referencia = referencia->ant;
        n--;
    }
    return referencia;
}

Nodo* Lista::Particion(Nodo* inicio, Nodo* fin){
    int pivote = fin->info->GetEntero();
    Nodo* i = inicio->ant;

    for (Nodo* j = inicio; j != fin; j = j->sig) {
        if (j->info->GetEntero() <= pivote) {
            i = (i == nullptr) ? inicio : i->sig;
            SwapInfo(i, j);
        }
    }

    i = (i == nullptr) ? inicio : i->sig;
    SwapInfo(i, fin);
    return i;
}

void Lista::QuickSort(Nodo* inicio, Nodo* fin){
     if (!inicio || !fin || inicio == fin || fin->sig == inicio)
        return; // evita llamadas inv�lidas

    Nodo* pivote = Particion(inicio, fin);

    if (pivote && pivote->ant && inicio != pivote)
        QuickSort(inicio, pivote->ant);

    if (pivote && pivote->sig && fin != pivote)
        QuickSort(pivote->sig, fin);
}
