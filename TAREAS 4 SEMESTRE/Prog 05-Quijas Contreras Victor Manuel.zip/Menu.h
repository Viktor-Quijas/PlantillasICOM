#ifndef MENU_H
#define MENU_H
#include "Lista.h"

class Menu
{
    public:
        void MenuPrincipal();
        void MenuInsercion();
        void MenuBuscar();
        void MenuEliminar();

        void InicializarLista();
        void Editar(Dato* dato);
        Dato* DatoFormato();

        //void InsertSort();

        Menu();
        ~Menu();

    protected:

    private:
        Lista* lista;
        Dato* dato;
        int eleccion;
        bool band;
        bool bandMenu;

        bool SetEleccion();

        int posicion;

        /*Datos de Dato*/
        int entero;

};

#endif // MENU_H
