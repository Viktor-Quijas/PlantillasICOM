#ifndef LISTA_H
#define LISTA_H
#include "Nodo.h"

using namespace std;

class Lista
{
    public:
            /*Funciones de insertar*/
        void InsertInicio(Dato* info);
        void InsertFinal(Dato* info);
        void InsertPosicion(Dato* info, int posicion);
        void InsertAntes(Dato* info, Nodo* posicion);
        void InsertDespues(Dato* info, Nodo* posicion);

            /*Funciones para buscar*/
        bool Vacia();
        int Tamanio();
        Nodo* Buscar (int posicion);    //Por posicion
        Nodo* BuscarEntero (int emterp);   //Por nombre
        Nodo* Primero();
        Nodo* Ultimo();
        Nodo* Siguiente(Nodo* referencia);
        Nodo* Anterior(Nodo* referencia);


            /*Funciones para mostrar*/
        void MostrarDato(Dato* aux);
        void MostrarDato(Nodo* aux);
        void MostrarLista();

            /*Funciones para eliminar*/
        void Eliminar(int posicion);
        void EliminarTodo();

            /*Ordenamientos*/
        void BubbleSort();
        void BetterBubleSort();
        void InsertionSort();
        void SelectionSort();
        void ShellSort();
        void QuickSort();


            /*Funciones complementarias*/
        void SwapInfo(Nodo* a, Nodo* b);
        bool Ordenado();
        void InsertarNodo(Nodo*a, Nodo* b);
        Nodo* BuscarGapAnterior(Nodo* actual, int n);
        Nodo* Particion(Nodo* inicio, Nodo* fin);
        void QuickSort(Nodo* inicio, Nodo* fin);

        Lista();
        ~Lista();

    protected:

    private:
        Nodo* cabeza;
        Nodo* cola;
};

#endif // LISTA_H
