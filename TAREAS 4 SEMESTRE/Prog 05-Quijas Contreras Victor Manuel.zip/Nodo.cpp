#include "Nodo.h"

Nodo::Nodo()
{
    info = nullptr;
    sig = nullptr;
    ant = nullptr;
}

Nodo::Nodo(Dato* info){
    this->info = info;
    sig = nullptr;
    ant = nullptr;
}

Nodo::Nodo(Dato* info, Nodo* sig, Nodo* ant){
    this->info = info;
    this->sig = sig;
    this->ant = ant;
}

Nodo::~Nodo()
{
    delete info;
}
