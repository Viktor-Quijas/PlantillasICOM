#include "Dato.h"

Dato::Dato()
{
    this->entero = 0;
}

Dato::Dato(int entero){
    SetEntero(entero);
}

Dato::~Dato()
{
    //dtor
}

        /*Setters*/
void Dato::SetEntero(int entero){
    this->entero = entero;
    return;
}

        /*Getters*/
int Dato::GetEntero(){return entero;}
