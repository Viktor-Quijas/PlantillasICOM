#ifndef DATO_H
#define DATO_H
#include <iostream>
using namespace std;

class Dato
{
    public:

        /*Datos a guardar*/
        int entero;

        /*Setters*/
        void SetEntero(int entero);

        /*Getters*/
        int GetEntero();

        Dato();
        Dato(int entero);
        ~Dato();

    protected:

    private:
};

#endif // DATO_H
