#include "Menu.h"
#include <stdlib.h>
#include <time.h>

Menu::Menu()
{
    band = false;
    eleccion = 0;
    lista = nullptr;
    dato = nullptr;
    posicion = 0;
}

Menu::~Menu()
{
    delete lista;
}

void Menu::MenuPrincipal(){
    while (true){
        system("cls");
        cout << "-----Lista doblemente ligada-----" << endl;
        cout << "\n" << "Seleccione una opcion:" << "\n" << endl;
        if (!band){
            cout << "0.Inicializar lista -> DEBE INICIALIZAR SU LISTA ANTES DE PODER USARLA" << "\n\n";
        }
        cout << "------Operaciones------" << endl;
        cout << "1.Insertar un Dato." << endl;
        cout << "2.Mostrar lista." << endl;
        cout << "3.Buscar un Dato." << endl;
        cout << "4.Eliminar." << endl;
        cout << "\n" << "------Ordenadores------" << endl;
        cout << "5.Bubble Sort 'Mejorada'" << endl;
        cout << "6.Insert Sort." << endl;
        cout << "7.Quick Sort." << endl;
        /*cout << "8.Bubble Sort." << endl;
        cout << "9.Selection Sort." << endl;
        cout << "10.Shell Sort." << endl;
        cout << "11.Merge Sort." << endl;*/
        cout << "\n" << "------Herramientas------" << endl;
        cout << "12.Generador de datos aleatorios." << endl;
        cout << "\n" << "13.Salir." << "\n\n";
        cout << "-> ";
        cin >> eleccion;

        switch(eleccion){
        case 0:
            InicializarLista();
            system("pause");
            band = true;
            break;
        case 1:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            MenuInsercion();
            break;
        case 2:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            system("cls");
            lista->MostrarLista();
            system("pause");
            break;
        case 3:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            MenuBuscar();
            break;
        case 4:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            MenuEliminar();
            break;

                    /*Ordenamientos*/
        case 5:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            lista->BetterBubleSort();
            if (lista->Ordenado()){
                cout << "Lista ordenada!" << endl;
            } else {
                cout << "Lista NO ordenada w" << endl;
            }
            system("pause");
            break;
        case 6:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            lista->InsertionSort();
            if (lista->Ordenado()){
                cout << "Lista ordenada!" << endl;
            } else {
                cout << "Lista NO ordenada w" << endl;
            }
            system("pause");
            break;
        case 7:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            lista->QuickSort();
            if (lista->Ordenado()){
                cout << "Lista ordenada!" << endl;
            } else {
                cout << "Lista NO ordenada w" << endl;
            }
            system("pause");
            break;
        case 8:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            lista->BubbleSort();
            if (lista->Ordenado()){
                cout << "Lista ordenada!" << endl;
            } else {
                cout << "Lista NO ordenada w" << endl;
            }
            system("pause");
            break;
        case 9:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            lista->SelectionSort();
            if (lista->Ordenado()){
                cout << "Lista ordenada!" << endl;
            } else {
                cout << "Lista NO ordenada w" << endl;
            }
            system("pause");
            break;
        case 10:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            lista->ShellSort();
            if (lista->Ordenado()){
                cout << "Lista ordenada!" << endl;
            } else {
                cout << "Lista NO ordenada w" << endl;
            }
            system("pause");
            break;
        case 11:
            //Merge Sort
            break;
        case 12:
            if (!band){
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
                break;
            }
            srand(time(NULL));

            for (int i = 0; i < 100; i++){
                dato = new Dato(rand() %101);
                lista->InsertInicio(dato);
            }
            system("pause");
            break;
        case 13:
            while (true){ //El return de todas formas truena el bucle �ya
                cout << endl << "Seguro que deseas salir del programa?" << endl;
                cout << "1.Si" << endl;
                cout << "2.No" << endl;
                cout << "-> ";
                cin >> eleccion;

                switch (eleccion){
                case 1:
                    return;
                case 2:
                    break;
                default:
                    cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
                    break;
                }
        }
        default:
            cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
            system("pause");
            break;
        }
    }
}

void Menu::InicializarLista(){
    if (band){ //Regresa si la lista ya est� creada
        cout << "La lista ya se encuentra inicializada!" << endl;
        return;
    }

    lista = new Lista(); //Crea la lista

    if (!lista){ //Verifica que exista el espacio asignado
        cout << "Error al asignar memoria a la lista." << endl;
        return;
    }

    cout << "Lista inicializada correctamente!" << endl;
    return;
}

void Menu::MenuInsercion(){
    cout << "\n\n" << "-----Menu de insercion-----" << endl;
    cout << "\n" << "Seleccione una opcion:" << endl;
    cout << "1. Insertar en posicion indicada." << endl;
    cout << "2. Insertar al inicio." << endl;
    if (!lista->Vacia())
        cout << "3. Insertar al final." << endl;
    cout << "0. Regresar." << endl;
    cout << "-> ";
    cin >> eleccion;

    switch (eleccion){
    case 1:
        if (!lista->Vacia())
            lista->MostrarLista();
        cout << "Ingrese la posicion: ";
        cin >> posicion;
        lista->InsertPosicion(DatoFormato(),posicion);
        system("pause");
        break;
    case 2:
        lista->InsertInicio(DatoFormato());
        system("pause");
        break;
    case 3:
        lista->InsertFinal(DatoFormato());
        system("pause");
        break;
    case 0:
        break;
    default:
        cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
        system("pause");
        MenuInsercion();
        break;
    }
}

void Menu::MenuBuscar(){
    bool bandnaco = true;
    cout << "\n\n" << "-----Menu de busqueda-----" << endl;
    cout << "\n" << "Seleccione una opcion:" << endl;
    cout << "1. Busqueda por rasgo" << endl;
    cout << "2. Primer Dato." << endl;
    cout << "3. Ultimo Dato." << endl;
    cout << "4. Anterior a Dato." << endl;
    cout << "5. Siguiente a Dato." << endl;
    cout << "0. Regresar." << endl;
    cout << "-> ";
    cin >> eleccion;

    switch (eleccion){
    case 1:
        while (bandnaco){
            cout << "\n\n" << "Seleccione una opcion:" << endl;
            cout << "1. Posicion." << endl;
            cout << "2. Entero." << endl;
            cout << "-> ";
            cin >> eleccion;

            switch(eleccion){
            case 1:
                cout << "\n\n" << "Ingrese la posicion: ";
                cin >> posicion;
                cout << endl;
                lista->MostrarDato(lista->Buscar(posicion));
                bandnaco = false;
                system("pause");
                break;
            case 2:
                cout << "\n\n" << "Ingrese el entero: ";
                cin >> entero;
                cout << endl;
                lista->MostrarDato(lista->Buscar(entero));
                bandnaco = false;
                system("pause");
                break;
            default:
                cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
                system("pause");
                break;
            }
        }
        break;
    case 2:
        cout << "\n\t" << "Primer Dato:" << endl;
        lista->MostrarDato(lista->Primero());
        system("pause");
        break;
    case 3:
        cout << "\n\t" << "Ultimo Dato:" << endl;
        lista->MostrarDato(lista->Ultimo());
        system("pause");
        break;
    case 4:
        if (!lista->Vacia())
            lista->MostrarLista();
        cout << "\n\n" << "Ingrese la posicion de referencia: ";
        cin >> posicion;
        cout << endl;
        cout << "\n\t" << "Dato anterior en la posicion '" << posicion << "':" << endl;
        lista->MostrarDato(lista->Anterior(lista->Buscar(posicion)));
        system("pause");
        break;
    case 5:
        if (!lista->Vacia())
            lista->MostrarLista();
        cout << "\n\n" << "Ingrese la posicion de referencia: ";
        cin >> posicion;
        cout << "\n\t" << "Dato siguiente en la posicion '" << posicion << "':" << endl;
        lista->MostrarDato(lista->Siguiente(lista->Buscar(posicion)));
        system("pause");
        break;
    case 0:
        break;
    default:
        cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
        system("pause");
        MenuBuscar();
        break;
    }
}

void Menu::MenuEliminar(){
    cout << "\n\n" << "-----Menu de busqueda-----" << endl;
    cout << "\n" << "Seleccione una opcion:" << endl;
    cout << "1. Eliminar un Dato." << endl;
    cout << "2. Eliminar lista." << endl;
    cout << "0. Salir." << endl;
    cout << "-> ";
    cin >> eleccion;

    switch(eleccion){
    case 1:
        lista->MostrarLista();
        cout << "\n\n" << "Ingrese la posicion de referencia: ";
        cin >> posicion;
        lista->Eliminar(posicion);
        cout << "\n" << "Dato eliminado correctamente!" << endl;
        system("pause");
        break;
    case 2:
        while (true){ //El return de todas formas truena el bucle �ya
            cout << "Estas seguro de eliminar toda la lista?" << endl;
            cout << "1.Si" << endl;
            cout << "2.No" << endl;
            cout << "-> ";
            cin >> eleccion;

            switch (eleccion){
            case 1:
                lista->EliminarTodo();
                band = false;
                return;
            case 2:
                return;
            default:
                cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
                break;
            }
        }
    case 0:
        break;
    default:
        cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
        system("pause");
        MenuEliminar();
        break;
    }
}

Dato* Menu::DatoFormato(){
    while (true){
        cout << "\n\n" << "-----Formato Dato-----" << endl;
        cout << "Ingrese el entero: " << endl;
        cin >> entero;
        //Aqu� se le pueden asignar m�s variables al Dato 0//0.

        dato = new Dato(entero);

        if (!dato){
            cout << "Error en la asignacion de memoria de dato." << endl;
            return nullptr;
        } else {
            cout << "\t" << "Guardado exitosamente!" << endl;
            lista->MostrarDato(dato);

            while (true){ //El return de todas formas truena el bucle �ya
                cout << "Desea corregir la informacion?" << endl;
                cout << "1.Si" << endl;
                cout << "2.No" << endl;
                cout << "-> ";
                cin >> eleccion;

                switch (eleccion){
                case 1:
                    Editar(dato);
                    return dato;
                case 2:
                    return dato;
                default:
                    cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
                    break;
                }
            }
        }
    }
    return nullptr;
}

void Menu::Editar(Dato* Dato){
    while(true){
        cout << "\n\n" << "Que desea editar?" << endl;
        cout << "1.Entero." << endl;
        cout << "-> ";
        cin >> eleccion;

        switch (eleccion){
        case 1:
            while (true) {
                cout << "\n" << "Ingrese el nuevo entero: " << endl;
                cin >> entero;

                dato->SetEntero(entero);
                cout << endl;
                lista->MostrarDato(dato);
                cout << "Entero guardado correctamente!" << endl;

                while (true){ //El return de todas formas truena el bucle �ya
                    cout << "Desea Editar algo mas?" << endl;
                    cout << "1.Si" << endl;
                    cout << "2.No" << endl;
                    cout << "-> ";
                    cin >> eleccion;

                    switch (eleccion){
                    case 1:
                        Editar(dato);
                        return; //Se supone que estas madres deber�an de jalar w jalskdjfsdf
                    case 2:
                        return;
                    default:
                        cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
                        break;
                    }
                }
            }
            break;
        default:
            cout << endl << "INGRESA UN DIGITO VALIDO!" << "\n\n";
            system("pause");
            break;
        }
    }
    return;
}

