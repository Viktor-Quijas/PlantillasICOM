#include "Arbol.h"

/*Constructores*/
Arbol::Arbol() {
	this->raiz = nullptr;
	this->tamanio = 0;
}

Arbol::~Arbol() {
	EliminarArbol(raiz);
}


/*Op Menu*/

void Arbol::PubInsertar(Dato* info) {
	raiz = Insertar(raiz, info);
	return;
}

void Arbol::PubMostrar(int eleccion) {
	switch (eleccion) {
	case 1:
		MostrarInOrder(raiz);	//1.MostrarInOrder
		cout << "x" << endl;
		break;
	case 2:
		MostrarPreOrder(raiz);	//2.MostrarPreOrder
		cout << "x" << endl;
		break;
	case 3:
		MostrarPosOrder(raiz);	//3.MostrarPosOrder
		cout << "x" << endl;
		break;
	default:
		cout << "Error al escoger la eleccion en Mostrar!" << endl;
		break;
	}
	return;
}

void Arbol::PubBuscar(int eleccion, int entero) {
	switch (eleccion) {
	case 1:
		MostrarNodo(Buscar(raiz, entero));	//1.Buscar 
		break;
	case 2: {
		int x = Tamanio();					//2. Tama�o
		cout << "La cantidad de nodos en el arbol es de: " << x;
		break;
		}
	case 3:
		if (Vacio())						//3.Vacio
			cout << "El arbol se encuentra vacio!" << endl;
		else
			cout << "El arbol cuenta con elementos." << endl;
		break;
	default:
		cout << "Error al escoger la eleccion en Mostrar!" << endl;
		break;
	}
}

void Arbol::PubEliminar(int eleccion, int entero) {
	switch (eleccion) {
	case 1:
		raiz = Eliminar(raiz, entero);	//1. Eliminar nodo en espec�fico
		break;
	case 2:
		EliminarArbol(raiz);			//2. Eliminar �rbol
		break;
	default:
		cout << "Error al escoger la eleccion en Mostrar!" << endl;
		break;
	}
}



		/*Operaciones*/

//Insertar
Nodo* Arbol::Insertar(Nodo* referencia, Dato* info) {
	if (!referencia) {
		Nodo* aux = new Nodo(info);
		tamanio++;
		return aux;
	}

	if (info->GetEntero() < referencia->info->GetEntero()) 
		referencia->l = Insertar(referencia->l, info);
	else 
		referencia->r = Insertar(referencia->r, info);

	return referencia;
}

//Mostrar
void Arbol::MostrarInOrder(Nodo* referencia) {
	if (!referencia) {
		return;
	}
	MostrarInOrder(referencia->l);
	cout << referencia->info->GetEntero() << "->";
	MostrarInOrder(referencia->r);
}

void Arbol::MostrarPreOrder(Nodo* referencia) {
	if (!referencia) {
		return;
	}
	cout << referencia->info->GetEntero() << "->";
	MostrarPreOrder(referencia->l);
	MostrarPreOrder(referencia->r);
}

void Arbol::MostrarPosOrder(Nodo* referencia) {
	if (!referencia) {
		return;
	}
	MostrarPosOrder(referencia->l);
	MostrarPosOrder(referencia->r);
	cout << referencia->info->GetEntero() << "->";
}

void Arbol::MostrarNodo(Nodo* referencia) {
	if (!referencia) {
		cout << "MostrarNodo: Referencia apuntando a nulo." << endl;
		return;
	}

	cout << endl << "--------------------------------" << endl;
	cout << "Entero: " << referencia->info->GetEntero() << endl;
	cout << "Flotante: " << referencia->info->GetFlotante() << endl;
	cout << "Caracter: " << referencia->info->GetCaracter() << endl;
	cout << "Cadena: " << referencia->info->GetCadena() << endl;
	cout << "--------------------------------" << endl;
	return;
}

void Arbol::CopiarDatos(Nodo* referencia, Nodo* heredero) {
	referencia->info->SetEntero(heredero->info->GetEntero());
	referencia->info->SetFlotante(heredero->info->GetFlotante());
	referencia->info->SetCaracter(heredero->info->GetCaracter());
	referencia->info->SetCadena(heredero->info->GetCadena());
	return;
}

//Busqueda
int Arbol::Tamanio() { return tamanio; }

bool Arbol::Vacio() { return raiz == nullptr; }

Nodo* Arbol::Buscar(Nodo* referencia, int entero) {
	if (!referencia) {
		cout << "Buscar: No existe el elemento en la lista!" << endl;
		return nullptr;
	}

	if (referencia->info->GetEntero() == entero) {
		return referencia;
	}
	if (referencia->info->GetEntero() > entero) {
		return Buscar(referencia->l, entero);
	}
	else {
		return Buscar(referencia->r, entero);
	}
}

Nodo* Arbol::Heredero(Nodo* referencia) {
	if (!referencia) {
		cout << "Heredero: Referencia apuntando a nulo!" << endl;
		return nullptr;
	}

	if (referencia->r)
		return Heredero(referencia->r);
	else
		return referencia;	
}


//Eliminar
Nodo* Arbol::Eliminar(Nodo* referencia, int entero) {
	if (!referencia) {
		return nullptr;
	}

	if (entero < referencia->info->GetEntero()) {
		referencia->l = Eliminar(referencia->l, entero);
	}
	else if (entero > referencia->info->GetEntero()){
		referencia->r = Eliminar(referencia->r, entero);
	}
	else {
		if (!referencia->l && !referencia->r) { //Nodo hoja
			tamanio--;
			delete referencia;
			return nullptr;
		}
		else if (!referencia->l || !referencia->r){ //Nodo rama
			if (referencia->l) {
				tamanio--;
				Nodo* temp = referencia->l;
				delete referencia;
				return temp;
			}
			else if (referencia->r) {
				tamanio--;
				Nodo* temp = referencia->r;
				delete referencia;
				return temp;
			}
		}
		else if (referencia->l && referencia->r) {		//Nodo rama (ambos hijos)
			Nodo* heredero = Heredero(referencia->l);
			CopiarDatos(referencia, heredero);
			referencia->l = Eliminar(heredero, heredero->info->GetEntero());
		}
	}
	return referencia;
}

void Arbol::EliminarArbol(Nodo* referencia) {
	if (!referencia) {
		return;
	}
	
	EliminarArbol(referencia->l);
	EliminarArbol(referencia->r);
	delete referencia;
}