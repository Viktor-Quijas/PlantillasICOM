#pragma once

#include "Dato.h"

class Nodo
{
public:
	Dato* info;
	Nodo* l;
	Nodo* r;

	Nodo();
	Nodo(Dato* info);
	Nodo(Dato* info, Nodo* l, Nodo* r);
	~Nodo();
};

