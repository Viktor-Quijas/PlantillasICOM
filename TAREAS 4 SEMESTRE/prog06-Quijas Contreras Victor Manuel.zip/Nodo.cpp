#include "Nodo.h"

/*Constructores*/
Nodo::Nodo() {
	this->info = nullptr;
	this->l = nullptr;
	this->r = nullptr;
}

Nodo::Nodo(Dato* info) {
	this->info = info;
	this->l = nullptr;
	this->r = nullptr;
}

Nodo::Nodo(Dato* info, Nodo* l, Nodo* r) {
	this->info = info;
	this->l = l;
	this->r = r;
}

Nodo::~Nodo() { delete info; }