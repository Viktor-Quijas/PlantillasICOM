#include <iostream>
#include <stdlib.h>
#include "Arbol.h"
#include "Dato.h"

int main()
{

    int i, entero;
    Dato* info;
    Arbol* arbol = new Arbol();

    for (i = 0; i < 100; i++) {
        entero = rand() % 101;
        info = new Dato(entero);
        arbol->PubInsertar(info);
    }
    
    arbol->PubMostrar(1);

    cout << "\n\n";

    arbol->PubBuscar(2, 0);
    
    cout << "\n\n";

    arbol->PubEliminar(1,99);

    arbol->PubMostrar(1);

    arbol->PubBuscar(1, 99);

    cout << "\n\n";

    arbol->PubBuscar(2, 0);
   
    arbol->PubEliminar(2,0); 

    cout << "\n\n";
    arbol->PubBuscar(2, 0);
}
