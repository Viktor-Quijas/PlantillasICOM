#include "Dato.h"

/*Setters*/
void Dato::SetEntero(int entero) {
	this->entero = entero;
}
void Dato::SetFlotante(float flotante) {
	this->flotante = flotante;
}
void Dato::SetCaracter(char caracter) {
	this->caracter = caracter;
}
void Dato::SetCadena(string cadena) {
	this->cadena = cadena;
}

/*Getters*/
int Dato::GetEntero() { return entero;}
float Dato::GetFlotante() { return flotante; }
char Dato::GetCaracter() { return caracter; }
string Dato::GetCadena() { return cadena; }

/*Constructores*/
Dato::Dato(int entero, float flotante, char caracter, string cadena){
	SetEntero(entero);
	SetFlotante(flotante);
	SetCaracter(caracter);
	SetCadena(cadena);
}

Dato::Dato(int entero) {
	SetEntero(entero);
	this->flotante = 0.0;
	this->caracter = ' ';
	this->cadena = " ";
}

Dato::Dato() {
	this->entero = 0;
	this->flotante = 0.0;
	this->caracter = ' ';
	this->cadena = " ";
}

Dato::~Dato() {}