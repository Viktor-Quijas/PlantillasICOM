#pragma once

#include <iostream>
#include <string>
using namespace std;

class Dato
{
private:
	int entero;
	float flotante;
	char caracter;
	string cadena;

public:

	/*Setters*/
	void SetEntero(int entero);
	void SetFlotante(float flotante);
	void SetCaracter(char caracter);
	void SetCadena(string cadena);

	/*Getters*/
	int GetEntero();
	float GetFlotante();
	char GetCaracter();
	string GetCadena();

	Dato(int entero, float flotante, char caracter, string cadena);
	Dato(int entero);
	Dato();
	~Dato();
};

