#pragma once
#include "Nodo.h"

class Arbol
{
private:
	Nodo* raiz;
	int tamanio;

public:
	/*Op Menu*/
	void PubInsertar(Dato* info);
	void PubMostrar(int eleccion);
	void PubBuscar(int eleccion, int entero);
	void PubEliminar(int eleccion, int entero);

	/*Operaciones*/
	Nodo* Insertar(Nodo* referencia, Dato* info);

	void MostrarInOrder(Nodo* referencia);
	void MostrarPreOrder(Nodo* referencia);
	void MostrarPosOrder(Nodo* referencia);
	void MostrarNodo(Nodo* referencia);
	void CopiarDatos(Nodo* referencia, Nodo* heredero);

	bool Vacio();
	int Tamanio();
	Nodo* Buscar(Nodo* referencia, int entero);
	Nodo* Heredero(Nodo* referencia);

	Nodo* Eliminar(Nodo* referencia, int entero);
	void EliminarArbol(Nodo* referencia);
	



	Arbol();
	~Arbol();
};

