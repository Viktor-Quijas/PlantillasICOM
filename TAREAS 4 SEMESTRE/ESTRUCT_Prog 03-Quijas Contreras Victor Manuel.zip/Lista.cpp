#include "Lista.h"

Lista::Lista()
{
    cabeza = nullptr;
    cola = nullptr;
}

Lista::~Lista()
{
    EliminarTodo();
}

        /*Funciones de insertar*/

void Lista::InsertInicio(Alumno* info){
    Nodo* aux;
    aux = new Nodo(info,cabeza,nullptr);

    if (aux){
        if (Vacia()){
            cola = aux;
            cabeza = aux;
        } else {
            cabeza->ant = aux;
            cabeza = aux;
        }
        cout << "Alumno insertado al inicio!" << endl;
    } else {
        cout << "Error en insercion, memoria no asignada." << endl;
    }
}

void Lista::InsertFinal(Alumno* info){
    Nodo* aux;
    aux = new Nodo(info,nullptr,cola);

    if (aux){
        if (Vacia()){
            cabeza = aux;
            cola = aux;
        } else {
            cola->sig = aux;
            cola = aux;
        }
        cout << "Alumno insertado al final!" << endl;
    } else {
        cout << "Error en insercion, memoria no asignada." << endl;
    }
}

void Lista::InsertAntes(Alumno* info,Nodo* temp){
    Nodo* aux = new Nodo(info,temp,temp->ant);

    if (aux){
        temp->ant->sig = aux;
        temp->ant = aux;
        cout << endl << "Alumno insertado correctamente!" << endl;
    } else {
        cout << endl << "Error en insercion, memoria no asignada." << endl;
    }
}

void Lista::InsertDespues(Alumno* info, Nodo* temp){
    Nodo* aux = new Nodo(info,temp->sig,temp);

    if (aux){
        temp->sig->ant = aux;
        temp->sig = aux;
        cout << endl << "Alumno insertado correctamente!" << endl;
    } else {
        cout << endl << "Error en insercion, memoria no asignada." << endl;
    }
}

void Lista::InsertPosicion(Alumno* info, int posicion){
    if (Vacia()){
        InsertInicio(info);
        cout << "Alumno insertado en la nueva lista!" << endl;
        return;
    } else if (posicion > Tamanio()){
        InsertFinal(info);
        cout << "Alumno insertado al final!" << endl;
        return;
    } else if (posicion < 0){
        cout << "Posicion invalida, recuerda usar SOLO enteros positivos." << endl;
        return;
    } else {
        int eleccion;

        cout << "\n\n" << "Deseas insertar antes o despues de la posicion?\n1.Antes\n2.Despues" << endl;
        cout << "-> ";
        cin >> eleccion;

        switch (eleccion){
        case 1:
            if (posicion == 1){
                InsertInicio(info);
                cout << endl << "Alumno insertado correctamente!" << endl;
                return;
            } else {
                Nodo* temp = Buscar(posicion);
                InsertAntes(info,temp);
                return;
            }
            break;
        case 2:
            if (posicion == Tamanio()){
                InsertFinal(info);
                cout << endl << "Alumno insertado correctamente!" << endl;
                return;
            } else {
                Nodo* temp = Buscar(posicion);
                InsertDespues(info,temp);
                return;
            }
            break;
        default:
            cout << "Ingresa un numero seleccionado en la lista!" << endl << endl;
            InsertPosicion(info, posicion);
            break;
        }
    }
}


        /*Funciones de busqueda*/

bool Lista::Vacia() {return cabeza == nullptr;}

int Lista::Tamanio(){
    Nodo* aux = cabeza;
    int tamanio;

    for (tamanio = 0; aux; tamanio++){
        aux = aux->sig;
    }

    return tamanio;
}

Nodo* Lista::Buscar(int posicion){
    if (posicion <= 0 || posicion > Tamanio()){
        cout << "Tu posicion no se encuentra en el rango de la lista, verificala." << endl;
        return nullptr;
    } else {
        Nodo* aux = cabeza;
        int i = 1;

        while (i != posicion){
            aux = aux->sig;
            i++;
        }
        cout << "Alumno encontrado!" << endl;
        return aux;
    }
}

Nodo* Lista::Buscar(string nombre){
    Nodo* aux = cabeza;

    while (aux && nombre != aux->info->GetNombre()){
        aux = aux->sig;
    }

    if (nombre == aux->info->GetNombre()){
        cout << "Alumno encontrado!" << endl;
        return aux;
    } else {
        cout << "El alumno no existe en esta lista." << endl;
        return nullptr;
    }
}

Nodo* Lista::Buscar(string nombre, string codigo){
    Nodo* aux = cabeza;

    while (aux && nombre != aux->info->GetNombre() && codigo == aux->info->GetCodigo()){
        aux = aux->sig;
    }

    if (nombre == aux->info->GetNombre() && codigo == aux->info->GetCodigo()){
        cout << "Alumno encontrado!" << endl;
        return aux;
    } else {
        cout << "El alumno no existe en esta lista." << endl;
        return nullptr;
    }
}

Nodo* Lista::Primero(){return cabeza;}

Nodo* Lista::Ultimo(){return cola;}

Nodo* Lista::Anterior(Nodo* referencia){
    if (referencia == Primero()){
        cout << "No existe ningun elemento anterior al primero!" << endl;
        return nullptr;
    } else if (referencia){
        return referencia->ant;
    } else {
        cout << "Referencia ingresada apuntando a nulo, revise su referencia." << endl;
        return nullptr;
    }

}

Nodo* Lista::Siguiente(Nodo* referencia){
    if (referencia == Ultimo()){
        cout << "No existe ningun elemento anterior al ultimo!" << endl;
    return nullptr;
    } else if (referencia){
        return referencia->sig;
    } else {
        cout << "Referencia ingresada apuntando a nulo, revise su referencia." << endl;
        return nullptr;
    }
}

        /*Funciones de mostrar*/

void Lista::MostrarAlumno(Alumno* referencia){
    if (referencia){
        cout << "*********************************************" << endl;
        cout << "Nombre: " << referencia->GetNombre() << endl;
        cout << "Edad: " << referencia->GetEdad() << endl;
        cout << "Carrera: " << referencia->GetCarrera() << endl;
        cout << "Promedio: " << referencia->GetPromedio() << endl;
        cout << "Codigo: " << referencia->GetCodigo() << endl;
        cout << "*********************************************" << "\n\n";
    } else {
        cout << "Referencia ingresada apuntando a nulo, revise su referencia." << endl;
    }
}

void Lista::MostrarAlumno(Nodo* referencia){
    if (referencia){
        cout << "*********************************************" << endl;
        cout << "Nombre: " << referencia->info->GetNombre() << endl;
        cout << "Edad: " << referencia->info->GetEdad() << endl;
        cout << "Carrera: " << referencia->info->GetCarrera() << endl;
        cout << "Promedio: " << referencia->info->GetPromedio() << endl;
        cout << "Codigo: " << referencia->info->GetCodigo() << endl;
        cout << "*********************************************" << "\n\n";
    } else {
        cout << "Referencia ingresada apuntando a nulo, revise su referencia." << endl;
    }
}

void Lista::MostrarLista(){
    if (cabeza){
        Nodo* aux = cabeza;
        int i = 1;
        while (aux){
        cout << "\t\t" << "Posicion: " << i << endl;;
        cout << "*********************************************" << endl;
        cout << "Nombre: " << aux->info->GetNombre() << endl;
        cout << "Edad: " << aux->info->GetEdad() << endl;
        cout << "Carrera: " << aux->info->GetCarrera() << endl;
        cout << "Promedio: " << aux->info->GetPromedio() << endl;
        cout << "Codigo: " << aux->info->GetCodigo() << endl;
        cout << "*********************************************" << "\n\n";
        i++;
        aux = aux->sig;
        }
    } else {
        cout << "Lista vacia!" << endl;
    }
}

void Lista::MostrarListaRevez(){
    if (cabeza){
        Nodo* aux = cola;
        int i = 1;
        while (aux){
        cout << "\t\t" << "Posicion: " << i << endl;;
        cout << "*********************************************" << endl;
        cout << "Nombre: " << aux->info->GetNombre() << endl;
        cout << "Edad: " << aux->info->GetEdad() << endl;
        cout << "Carrera: " << aux->info->GetCarrera() << endl;
        cout << "Promedio: " << aux->info->GetPromedio() << endl;
        cout << "Codigo: " << aux->info->GetCodigo() << endl;
        cout << "*********************************************" << "\n\n";
        i++;
        aux = aux->ant;
        }
    } else {
        cout << "Lista vacia!" << endl;
    }
}

void Lista::Eliminar(int posicion){
    Nodo* temp = Buscar(posicion);

    if (temp){
        if (temp == cabeza){
            temp->sig->ant = nullptr;
            cabeza = temp->sig;
            delete temp;
            cout << "Primer miembro de la lista eliminado!" << endl;
            return;
        } else if (temp == cola){
            temp->ant->sig = nullptr;
            cola = temp->ant;
            delete temp;
            cout << "Ultimo miembro de la lista eliminado!" << endl;
            return;
        } else {
            temp->ant->sig = temp->sig;
            temp->sig->ant = temp->ant;
            delete temp;
        }
    } else {
        cout << "No se encontro el miembro que buscabas eliminar." << endl;
    }
}

void Lista::EliminarTodo(){
    Nodo* aux = cabeza;
    Nodo* auxR;
    cabeza = nullptr;
    cola = nullptr;

    while (aux){
        auxR = aux;
        aux = aux->sig;
        delete auxR;
    }

    auxR = nullptr;

    cout << "Lista eliminada con exito!" << endl;
}
