#include "Alumno.h"

        /*Constructores*/

Alumno::Alumno()
{
    nombre = "Desconocido";
    codigo = "000000000";
    edad = 0;
    promedio = 0.0;
    carrera = "Desconocida";
}

Alumno::Alumno(string nombre, string codigo){
    SetNombre(nombre);
    SetCodigo(codigo);
    edad = 0;
    promedio = 0.0;
    carrera = "Desconocida";
}

Alumno::Alumno(string nombre, float promedio, string codigo){
    SetNombre(nombre);
    SetCodigo(codigo);
    SetPromedio(promedio);
    edad = 0;
    carrera = "Desconocida";
}

Alumno::Alumno(string nombre, int edad, string carrera, float promedio, string codigo){
    SetNombre(nombre);
    SetCodigo(codigo);
    SetPromedio(promedio);
    SetEdad(edad);
    SetCarrera(carrera);
}

Alumno::~Alumno()
{
    //dtor
}

        /*Setters*/

bool Alumno::SetNombre(string nombre){
    regex vNombre(R"(^[A-Za-z]+(\s[A-Za-z]+)*$)");
    if (regex_match(nombre,vNombre)){
        this->nombre = nombre;
        return true;
    } else {
        cout << "ADVERTENCIA: Nombre invalido, intente no dejar espacios al final ni dos espacios entre nombres." << endl;
        this->nombre = "Desconocido";
        return false;
    }
}

bool Alumno::SetEdad(int edad) {
    if (edad > 4 && edad < 80){     //4 poq cuando has visto a un morro de 3 a�os estudiando
        this->edad = edad;
        return true;
    } else {
        cout << "ADVERTENCIA: Edad invalida, el rango de edades va de 4 a 80 anios." << endl;
        this->edad = 0;
        return false;
    }
}

bool Alumno::SetCarrera(string carrera){
    regex vCarrera(R"(^[^1-9]+$)");
    if (regex_match(carrera,vCarrera)){
        this->carrera = carrera;
        return true;
    } else {
        cout << "ADVERTENCIA: Carrera invalida, ingrese SOLO el NOMBRE de la carrera." << endl;
        this->carrera = "Desconocida";
        return false;
    }
}

bool Alumno::SetPromedio(float promedio) {
    if (promedio > 0 && promedio <= 100){     //4 poq cuando has visto a un morro de 3 a�os estudiando
        this->promedio = promedio;
        return true;
    } else {
        cout << "ADVERTENCIA: Promedio invalida, el rango del promedio es de: 0 al 100." << endl;
        this->promedio = 0.0;
        return false;
    }
}

bool Alumno::SetCodigo(string codigo){
    regex vCodigo(R"(^[0-9]{9}$)");
    if (regex_match(codigo,vCodigo)){
        this->codigo = codigo;
        return true;
    } else {
        cout << "ADVERTENCIA: Codigo invalido, codigo de la udg cuenta con 9 digitos: '123456789'." << endl;
        this->codigo = "Desconocida";
        return false;
    }
}

        /*Getters*/

string Alumno::GetNombre(){return nombre;}
int Alumno::GetEdad(){return edad;}
string Alumno::GetCarrera(){return carrera;}
float Alumno::GetPromedio(){return promedio;}
string Alumno::GetCodigo(){return codigo;}
