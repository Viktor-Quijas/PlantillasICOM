#ifndef ALUMNO_H
#define ALUMNO_H
#include <string>
#include <iostream>
#include <regex>
using namespace std;



class Alumno
{
    public:
        /*Setters*/
        bool SetNombre(string nombre);
        bool SetEdad(int edad);
        bool SetCarrera(string carrera);
        bool SetPromedio(float promedio);
        bool SetCodigo(string codigo);

        /*Getters*/
        string GetNombre();
        int GetEdad();
        string GetCarrera();
        float GetPromedio();
        string GetCodigo();


        Alumno(string nombre, string codigo);
        Alumno(string nombre, float promedio, string codigo);
        Alumno(string nombre, int edad, string carrera, float promedio, string codigo);
        Alumno();
        ~Alumno();

    protected:

    private:
        string nombre;
        int edad;
        string carrera;
        float promedio;
        string codigo;
};

#endif // ALUMNO_H
