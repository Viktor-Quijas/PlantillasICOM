#ifndef MENU_H
#define MENU_H
#include "Lista.h"

class Menu
{
    public:
        void MenuPrincipal();
        void MenuInsercion();
        void MenuBuscar();
        void MenuEliminar();

        void InicializarLista();
        void Editar(Alumno* alumno);
        Alumno* AlumnoFormato();

        Menu();
        ~Menu();

    protected:

    private:
        Lista* lista;
        Alumno* alumno;
        int eleccion;
        bool band;
        bool bandMenu;
        bool bandEditar;

        bool SetEleccion();

        int posicion;

        /*Datos de alumno*/
        string nombre;
        int edad;
        string carrera;
        float promedio;
        string codigo;
};

#endif // MENU_H
