#include "Menu.h"

Menu::Menu()
{
    band = false;
    bandMenu = true;
    eleccion = 0;
    lista = nullptr;
    alumno = nullptr;
    bandEditar = false;
    posicion = 0;
}

Menu::~Menu()
{
    delete lista;
}

void Menu::MenuPrincipal(){
    while (bandMenu){
        system("cls");
        cout << "-----Lista doblemente ligada-----" << endl;
        cout << "\n" << "Seleccione una opcion:" << "\n" << endl;
        if (!band){
            cout << "DEBE INICIALIZAR SU LISTA ANTES DE PODER USARLA" << "\n\n";
        }
        if (!band){
            cout << "0.Inicializar lista." << endl;
        }
        cout << "1.Insertar un Alumno." << endl;
        cout << "2.Mostrar lista." << endl;
        cout << "3.Buscar un Alumno." << endl;
        cout << "4.Eliminar." << endl;
        cout << "5.Salir." << endl;
        cout << "-> ";
        cin >> eleccion;

        switch(eleccion){
        case 0:
            InicializarLista();
            system("pause");
            band = true;
            break;
        case 1:
            if (band){
                MenuInsercion();
            } else {
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
            }
            break;
        case 2:
            if (band){
                system("cls");
                lista->MostrarLista();
                system("pause");
            } else {
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
            }
            break;
        case 3:
            if (band){
                MenuBuscar();
            } else {
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
            }
            break;
        case 4:
            if (band){
                MenuEliminar();
            } else {
                cout << "SE DEBE INICIALIZAR LA LISTA PRIMERO" << endl;
                system("pause");
            }
            break;
        case 5:
           cout << "\n\n"  << "Seguro que deseas salir del programa?" << endl;
            cout << "1.Si." << endl;
            cout << "Cualquier tecla: No." << endl;
            cout << "-> ";
            cin >> eleccion;

            if (eleccion == 1){
                bandMenu = false;
            }
            break;
        default:
            cout << "\n\n" << "Ingrese un digito valido!!" << endl;
            system("pause");
            break;
        }
    }
}

void Menu::InicializarLista(){
    if (band){
        cout << "La lista ya se encuentra inicializada!" << endl;
    } else {
        lista = new Lista();
        if (lista){
            cout << "Lista inicializada correctamente!" << endl;
        } else {
            cout << "Error al asignar memoria a la lista." << endl;
        }
    }
    return;
}

void Menu::MenuInsercion(){
    cout << "\n\n" << "-----Menu de insercion-----" << endl;
    cout << "\n" << "Seleccione una opcion:" << endl;
    cout << "1. Insertar en posicion indicada." << endl;
    cout << "2. Insertar al inicio." << endl;
    if (!lista->Vacia())
        cout << "3. Insertar al final." << endl;
    cout << "0. Regresar." << endl;
    cout << "-> ";
    cin >> eleccion;

    switch (eleccion){
    case 1:
        if (!lista->Vacia())
            lista->MostrarLista();
        cout << "Ingrese la posicion: ";
        cin >> posicion;
        lista->InsertPosicion(AlumnoFormato(),posicion);
        system("pause");
        break;
    case 2:
        lista->InsertInicio(AlumnoFormato());
        system("pause");
        break;
    case 3:
        lista->InsertFinal(AlumnoFormato());
        system("pause");
        break;
    case 0:
        break;
    default:
        cout << "\n\n" << "Ingrese un digito valido!!" << endl;
        system("pause");
        MenuInsercion();
        break;
    }
}

void Menu::MenuBuscar(){
    bool bandnaco = true;
    cout << "\n\n" << "-----Menu de busqueda-----" << endl;
    cout << "\n" << "Seleccione una opcion:" << endl;
    cout << "1. Busqueda por rasgo" << endl;
    cout << "2. Primer alumno." << endl;
    cout << "3. Ultimo alumno." << endl;
    cout << "4. Anterior a alumno." << endl;
    cout << "5. Siguiente a alumno." << endl;
    cout << "0. Regresar." << endl;
    cout << "-> ";
    cin >> eleccion;

    switch (eleccion){
    case 1:
        while (bandnaco){
            cout << "\n\n" << "Seleccione una opcion:" << endl;
            cout << "1. Posicion." << endl;
            cout << "2. Nombre." << endl;
            cout << "3. Nombre y codigo." << endl;
            cout << "-> ";
            cin >> eleccion;

            switch(eleccion){
            case 1:
                cout << "\n\n" << "Ingrese la posicion: ";
                cin >> posicion;
                cout << endl;
                lista->MostrarAlumno(lista->Buscar(posicion));
                bandnaco = false;
                system("pause");
                break;
            case 2:
                cout << "\n\n" << "Ingrese el nombre: ";
                cin >> nombre;
                cout << endl;
                lista->MostrarAlumno(lista->Buscar(nombre));
                bandnaco = false;
                system("pause");
                break;
            case 3:
                cout << "\n\n" << "Ingrese el nombre: ";
                cin >> nombre;
                cout << "Ingrese el codigo: ";
                cin >> codigo;
                cout << endl;
                lista->MostrarAlumno(lista->Buscar(nombre,codigo));
                bandnaco = false;
                system("pause");
                break;
            default:
                cout << "\n\n" << "Ingrese un digito valido!!" << endl;
                system("pause");
                break;
            }
        }
        break;
    case 2:
        cout << "\n\t" << "Primer alumno:" << endl;
        lista->MostrarAlumno(lista->Primero());
        system("pause");
        break;
    case 3:
        cout << "\n\t" << "Ultimo alumno:" << endl;
        lista->MostrarAlumno(lista->Ultimo());
        system("pause");
        break;
    case 4:
        if (!lista->Vacia())
            lista->MostrarLista();
        cout << "\n\n" << "Ingrese la posicion de referencia: ";
        cin >> posicion;
        cout << endl;
        cout << "\n\t" << "Alumno anterior en la posicion '" << posicion << "':" << endl;
        lista->MostrarAlumno(lista->Anterior(lista->Buscar(posicion)));
        system("pause");
        break;
    case 5:
        if (!lista->Vacia())
            lista->MostrarLista();
        cout << "\n\n" << "Ingrese la posicion de referencia: ";
        cin >> posicion;
        cout << "\n\t" << "Alumno siguiente en la posicion '" << posicion << "':" << endl;
        lista->MostrarAlumno(lista->Siguiente(lista->Buscar(posicion)));
        system("pause");
        break;
    case 0:
        break;
    default:
        cout << "\n\n" << "Ingrese un digito valido!!" << endl;
        system("pause");
        MenuBuscar();
        break;
    }
}

void Menu::MenuEliminar(){
    cout << "\n\n" << "-----Menu de busqueda-----" << endl;
    cout << "\n" << "Seleccione una opcion:" << endl;
    cout << "1. Eliminar un alumno." << endl;
    cout << "2. Eliminar lista." << endl;
    cout << "0. Salir." << endl;
    cout << "-> ";
    cin >> eleccion;

    switch(eleccion){
    case 1:
        lista->MostrarLista();
        cout << "\n\n" << "Ingrese la posicion de referencia: ";
        cin >> posicion;
        lista->Eliminar(posicion);
        cout << "\n" << "Alumno eliminado correctamente!" << endl;
        system("pause");
        break;
    case 2:
        cout << "\n\n" << "Estas seguro de eliminar toda la lista?" << endl;
        cout << "1.Si." << endl;
        cout << "Cualquier digito: No." << endl;
        cout << "-> ";
        cin >> eleccion;

        if (eleccion == 1){
            lista->EliminarTodo();
            band = false;
            system("pause");
        }
        break;
    case 0:
        break;
    default:
        cout << "\n\n" << "Ingrese un digito valido!!" << endl;
        system("pause");
        MenuEliminar();
        break;
    }
}

Alumno* Menu::AlumnoFormato(){
    bool naconaco = true;
    while (naconaco){
        cout << "\n\n" << "-----Formato alumno-----" << endl;
        cout << "Seleccione una opcion:" << endl;
        cout << "1.Ingresar solo nombre y codigo." << endl;
        cout << "2.Ingresar nombre, codigo y promedio." << endl;
        cout << "3.Ingresar Formato completo." << endl;
        cout << "-> ";
        cin >> eleccion;

        switch (eleccion){
        case 1:
            cout << "\n\n" << "Nombre: ";
            cin.ignore();
            getline(cin,nombre);
            cout << "Codigo: ";
            cin >> codigo;
            cout << "\n\n";

            alumno = new Alumno(nombre,codigo);

            if (alumno){
                cout << "\t" << "Guardado exitosamente!" << endl;
                lista->MostrarAlumno(alumno);

                cout << "Desea corregir la informacion?" << endl;
                cout << "1.Si" << endl;
                cout << "Cualquier digito: No" << endl;
                cout << "-> ";
                cin >> eleccion;

                if (eleccion == 1) {
                Editar(alumno);
                }
                return alumno;

            } else {
                cout << "Error al asignar memoria para el Alumno." << endl;
                return nullptr;
            }
        case 2:
            cout << "\n\n" << "Nombre: ";
            cin.ignore();
            getline(cin,nombre);
            cout << "Codigo: ";
            cin >> codigo;
            cout << "Promedio: ";
            cin >> promedio;
            cout << "\n\n";

            alumno = new Alumno(nombre,promedio,codigo);

            if (alumno){
                cout << "\t" << "Guardado exitosamente!" << endl;
                lista->MostrarAlumno(alumno);

                cout << "Desea corregir la informacion?" << endl;
                cout << "1.Si" << endl;
                cout << "Cualquier digito: No" << endl;
                cout << "-> ";
                cin >> eleccion;

                if (eleccion == 1) {
                Editar(alumno);
                }
                return alumno;

            } else {
                cout << "Error al asignar memoria para el Alumno." << endl;
                return nullptr;
            }
        case 3:
            cout << "\n\n" << "Nombre: ";
            cin.ignore();
            getline(cin,nombre);
            cout << "Edad: ";
            cin >> edad;
            cout << "Carrera: ";
            cin.ignore();
            getline(cin,carrera);
            cout << "Promedio: ";
            cin >> promedio;
            cout << "Codigo: ";
            cin >> codigo;
            cout << "\n\n";

            alumno = new Alumno(nombre,edad,carrera,promedio,codigo);

            if (alumno){
                cout << "\t" << "Guardado exitosamente!" << endl;
                lista->MostrarAlumno(alumno);

                cout << "Desea corregir la informacion?" << endl;
                cout << "1.Si" << endl;
                cout << "Cualquier digito: No" << endl;
                cout << "-> ";
                cin >> eleccion;

                if (eleccion == 1) {
                Editar(alumno);
                }
                return alumno;

            } else {
                cout << "Error al asignar memoria para el Alumno." << endl;
                return nullptr;
            }
        default:
            cout << "\n\n" << "Ingrese un digito valido!!" << endl;
            system("pause");
            break;
        }
    }
    return nullptr;
}

void Menu::Editar(Alumno* alumno){
    bandEditar = true; //<- Comienza el bucle
    bool bandnaco; //<-Mi nacada
    while(bandEditar){
        cout << "\n\n" << "Que desea editar?" << endl;
        cout << "1.Nombre." << endl;
        cout << "2.Edad." << endl;
        cout << "3.Carrera." << endl;
        cout << "4.Promedio." << endl;
        cout << "5.Codigo." << endl;
        cout << "-> ";
        cin >> eleccion;



        switch (eleccion){
        case 1:
            bandnaco = true;
            while (bandnaco) {
                cout << "\n" << "Ingrese el nuevo nombre: " << endl;
                cin.ignore();
                getline(cin,nombre);
                if (alumno->SetNombre(nombre)){
                    cout << endl;
                    lista->MostrarAlumno(alumno);
                    cout << "Nombre guardado correctamente!" << endl;
                    cout << "\n" << "Desea editar algo mas?" << endl;
                    cout << "1.Si" << endl;
                    cout << "Cualquier digito: No" << endl;
                    cout << "-> ";
                    cin >> eleccion;

                    if (eleccion == 2) {
                        bandnaco = false;
                    } else {
                        bandnaco = false;
                        bandEditar = false;
                    }
                } else {
                    cout << endl << "Intente nuevamente." << "\n\n";
                }
            }
            break;
        case 2:
            bandnaco = true;
            while (bandnaco) {
                cout << "\n" << "Ingrese la nueva edad: " << endl;
                cin >> edad;
                if (alumno->SetEdad(edad)){
                    cout << endl;
                    lista->MostrarAlumno(alumno);
                    cout << "Edad guardada correctamente!" << endl;
                    cout << "\n" << "Desea editar algo mas?" << endl;
                    cout << "1.Si" << endl;
                    cout << "Cualquier digito: No" << endl;
                    cout << "-> ";
                    cin >> eleccion;

                    if (eleccion == 2) {
                        bandnaco = false;
                    } else {
                        bandnaco = false;
                        bandEditar = false;
                    }
                } else {
                    cout << endl << "Intente nuevamente." << "\n\n";
                }
            }
            break;
        case 3:
            bandnaco = true;
            while (bandnaco) {
                cout << "\n" << "Ingrese la nueva carrera: " << endl;
                cin.ignore();
                getline(cin,carrera);
                if (alumno->SetCarrera(carrera)){
                    cout << endl;
                    lista->MostrarAlumno(alumno);
                    cout << "Carrera guardada correctamente!" << endl;
                    cout << "\n" << "Desea editar algo mas?" << endl;
                    cout << "1.Si" << endl;
                    cout << "Cualquier digito: No" << endl;
                    cout << "-> ";
                    cin >> eleccion;

                    if (eleccion == 2) {
                        bandnaco = false;
                    } else {
                        bandnaco = false;
                        bandEditar = false;
                    }
                } else {
                    cout << endl << "Intente nuevamente." << "\n\n";
                }
            }
            break;
        case 4:
            bandnaco = true;
            while (bandnaco) {
                cout << "\n" << "Ingrese el nuevo promedio: " << endl;
                cin >> promedio;
                if (alumno->SetPromedio(promedio)){
                    cout << endl;
                    lista->MostrarAlumno(alumno);
                    cout << "Promedio guardado correctamente!" << endl;
                    cout << "\n" << "Desea editar algo mas?" << endl;
                    cout << "1.Si" << endl;
                    cout << "Cualquier digito: No" << endl;
                    cout << "-> ";
                    cin >> eleccion;

                    if (eleccion == 2) {
                        bandnaco = false;
                    } else {
                        bandnaco = false;
                        bandEditar = false;
                    }
                } else {
                    cout << endl << "Intente nuevamente." << "\n\n";
                }
            }
            break;
        case 5:
            bandnaco = true;
            while (bandnaco) {
                cout << "\n" << "Ingrese el nuevo codigo: " << endl;
                cin >> codigo;
                if (alumno->SetCodigo(codigo)){
                    cout << endl;
                    lista->MostrarAlumno(alumno);
                    cout << "Codigo guardado correctamente!" << endl;
                    cout << "\n" << "Desea editar algo mas?" << endl;
                    cout << "1.Si" << endl;
                    cout << "Cualquier digito: No" << endl;
                    cout << "-> ";
                    cin >> eleccion;

                    if (eleccion == 2) {
                        bandnaco = false;
                    } else {
                        bandnaco = false;
                        bandEditar = false;
                    }
                } else {
                    cout << endl << "Intente nuevamente." << "\n\n";
                }
            }
            break;
        default:
            cout << "\n\n" << "Ingrese un digito valido!!" << endl;
            system("pause");
            break;
        }
    }
    return;
}

