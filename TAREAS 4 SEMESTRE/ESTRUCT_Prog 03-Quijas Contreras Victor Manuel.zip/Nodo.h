#ifndef NODO_H
#define NODO_H
#include "Alumno.h"


class Nodo
{
    public:
        Alumno* info;
        Nodo* sig;
        Nodo* ant;


        Nodo(Alumno* info);
        Nodo(Alumno* info, Nodo* sig, Nodo* ant);
        Nodo();
        ~Nodo();

    protected:

    private:
};

#endif // NODO_H


