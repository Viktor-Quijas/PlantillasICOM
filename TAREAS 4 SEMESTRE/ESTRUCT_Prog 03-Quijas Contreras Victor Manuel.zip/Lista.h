#ifndef LISTA_H
#define LISTA_H
#include "Nodo.h"

using namespace std;

class Lista
{
    public:
            /*Funciones de insertar*/
        void InsertInicio(Alumno* info);
        void InsertFinal(Alumno* info);
        void InsertPosicion(Alumno* info, int posicion);
        void InsertAntes(Alumno* info, Nodo* posicion);
        void InsertDespues(Alumno* info, Nodo* posicion);

            /*Funciones para buscar*/
        bool Vacia();
        int Tamanio();
        Nodo* Buscar (int posicion);    //Por posicion
        Nodo* Buscar (string nombre);   //Por nombre
        Nodo* Buscar (string nombre, string codigo);    //Por nombre y codigo
        Nodo* Primero();
        Nodo* Ultimo();
        Nodo* Siguiente(Nodo* referencia);
        Nodo* Anterior(Nodo* referencia);


            /*Funciones para mostrar*/
        void MostrarAlumno(Alumno* aux);
        void MostrarAlumno(Nodo* aux);
        void MostrarLista(); //Experimental: no est� dentro del proyecto.
        void MostrarListaRevez();

            /*Funciones para eliminar*/
        void Eliminar(int posicion);
        void EliminarTodo();

        Lista();
        ~Lista();

    protected:

    private:
        Nodo* cabeza;
        Nodo* cola;
};

#endif // LISTA_H
