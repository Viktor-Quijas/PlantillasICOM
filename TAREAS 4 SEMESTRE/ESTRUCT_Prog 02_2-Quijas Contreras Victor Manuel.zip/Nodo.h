#ifndef NODO_H
#define NODO_H
#include "Alumno.h"


class Nodo
{
    public:
        Alumno* info;
        Nodo* ptr;

        Nodo();
        Nodo(Alumno* info);
        Nodo(Alumno* info,Nodo* ptr);
        ~Nodo();

    protected:

    private:
};

#endif // NODO_H
