#include "Menu.h"
#include <iostream>

/*M�todos de b�squeda*/
#define POSICION 1
#define NOMBRE 2
#define NOMYCOD 3

using namespace std;

void Menu::Menu_principal(){
    while (centinela){
        system("cls");
        cout << "\t---Lista Simplemente Ligada---" << endl << endl;
        if(band == false)
            cout << "1. Inicializar lista." << endl;
        cout << "2. Insertar un elemento." << endl;
        cout << "3. Mostrar la lista." << endl;
        cout << "4. Buscar un elemento." << endl;
        cout << "5. Eliminar un elemento." << endl;
        cout << "6. Eliminar lista." << endl;
        cout << "7. Salir." << endl;
        cout << "-> ";
        cin >> eleccion;

        switch (eleccion){
        case 1:
            if (Validacion()){
                Inicializar_lista();
                band = true;
                system("pause");
            }
            else {
                cout << "La lista ya fue creada." << endl;
                system("pause");
            }
            break;
        case 2:
            if (Validacion()){
                cout << endl << "Es ESTRICTAMENTE necesario inicializar la lista primero." << endl;
                system("pause");
            }
            else {
                Insertar_elemento();
                system("pause");
            }
            break;
        case 3:
            if (Validacion()){
                cout << endl << "Es ESTRICTAMENTE necesario inicializar la lista primero." << endl;
                system("pause");
            }
            else {
                Mostrar_lista();
                system("pause");
            }
            break;
        case 4:
            if (Validacion()){
                cout << endl << "Es ESTRICTAMENTE necesario inicializar la lista primero." << endl;
                system("pause");
            }
            else {
                Buscar_elemento();
                system("pause");
            }
            break;
        case 5:
            if (Validacion()){
                cout << endl << "Es ESTRICTAMENTE necesario inicializar la lista primero." << endl;
                system("pause");
            }
            else {
                Eliminar_elemento();
                system("pause");
            }
            break;
        case 6:
            if (Validacion()){
                cout << endl << "Es ESTRICTAMENTE necesario inicializar la lista primero." << endl;
                system("pause");
            }
            else {
                Eliminar_lista();
                system("pause");
            }
            break;
        case 7:
            Salir();
            system("pause");
            centinela = false;
            break;
        default:
            cout << "Ingrese un digito valido." << endl;
            system("pause");
            break;
        }
    }
    return;
}

void Menu::Inicializar_lista(){
    l = new Lista();
    cout << "Lista creada correctamente!" << endl;
    return;
}

void Menu::Insertar_elemento(){
    Formato_alumno();
    cout << endl << "Indique la posicion donde va insertar el dato." << endl << endl;
    cout << "1. Insertar al inicio." << endl;
    if (!l->Vacio())
        cout << "2. Insertar al final." << endl;
    cout << "3. Insertar en posicion." << endl;
    cout << "4. Regresar al menu." << endl;
    cout << "-> ";
    cin >> eleccion;
    cout << endl;

    switch(eleccion){
    case 1:
        l->Insert_inicio(dato);
        break;
    case 2:
        l->Insert_final(dato);
        break;
    case 3:
        if (!l->Vacio())
            l->Mostrar_todo();
        cout << endl << "Ingrese la posicion: ";
        cin >> posicion;
        l->Insertar_posicion(posicion,dato);
        break;
    case 4:
        cout << "Seguro que deseas regresar?\t1.Si\t2.Noo" << endl;
        cout << "-> ";
        cin >> eleccion;
        if (eleccion == 2){
            Insertar_elemento();
        }
        break;
    default:
        cout << "Ingrese un digito valido." << endl;
        system("pause");
        Insertar_elemento();
        break;
    }
    return;
}

void Menu::Buscar_elemento(){
    system("cls");
    cout << "Indique lo que va a buscar. " << endl << endl;
    cout << "1. Buscar." << endl;
    cout << "2. Buscar el primero." << endl;
    cout << "3. Buscar el ultimo." << endl;
    cout << "4. Buscar el siguiente a." << endl;
    cout << "5. Buscar el anterior a." << endl;
    cout << "6. Regresar al menu principal." << endl;
    cout << "-> ";
    cin >> eleccion;
    cout << endl;


    switch(eleccion){
    case 1:
        Formato_buscar();
        break;
    case 2:
        l->Mostrar_enPosicion(l->Primero());
        break;
    case 3:
        l->Mostrar_enPosicion(l->Ultimo());
        break;
    case 4:
        cout << "Buscar al siguiente." << endl;
        cout << "Ingrese la posicion de la referencia: ";
        cin >> posicion;
        cout << "\n\n\t" << "**Actual**" << endl;
        l->Mostrar_enPosicion(l->Siguiente(l->Buscar(posicion,nombre,codigo,POSICION)));
        cout << "\t**Siguiente**" << endl;
        break;
    case 5:
        cout << "Buscar al anterior." << endl;
        cout << "Ingrese la posicion de la referencia: ";
        cin >> posicion;
        cout << "\n\n\t" << "**Actual**" << endl;
        l->Mostrar_enPosicion(l->Anterior(l->Buscar(posicion,nombre,codigo,POSICION)));
        cout << "\t**Siguiente**" << endl;
        break;
    case 6:
        cout << "Seguro que deseas regresar?\t1.Si\t2.Noo" << endl;
        cout << "-> ";
        cin >> eleccion;
        if (eleccion == 2){
            Buscar_elemento();
        }
        break;
    default:
        cout << "Ingrese un digito valido." << endl;
        system("pause");
        Buscar_elemento();
        break;
    }
    return;
}

void Menu::Eliminar_elemento(){
    system("cls");
    l->Mostrar_todo();
    cout << "Ingresa la posicion del elemento que deseas eliminar: ";
    cin >> posicion;

    cout << endl << "***Estas seguro de eliminar este elemento?***" << endl << "No puedes deshacer la accion." << endl;
    cout << "1.Si\t2.No" << endl;
    cout << "-> ";
    cin >> eleccion;

    switch (eleccion){
    case 1:
        l->Eliminar(posicion);
        break;
    case 2:
        cout << "Transfiriendote a Menu Principal..." << endl;
        system("pause");
        Menu_principal();
        break;
    default:
        cout << "Ingrese un digito valido." << endl;
        system("pause");
        Eliminar_elemento();
        break;
    }
    return;
}

void Menu::Eliminar_lista(){
    system("cls");
    cout << endl << "***Estas seguro de ELIMINAR la lista por COMPLETO?***" << endl << "No puedes deshacer la accion." << endl;
    cout << "1.Si\t2.No" << endl;
    cout << "-> ";
    cin >> eleccion;

    switch (eleccion){
    case 1:
        l->Eliminar_Todo();
        band = false;
        break;
    case 2:
        cout << "Transfiriendote a Menu Principal..." << endl;
        system("pause");
        Menu_principal();
        break;
    default:
        cout << "Ingrese un digito valido." << endl;
        system("pause");
        Eliminar_elemento();
        break;
    }
    return;
}

void Menu::Salir(){
    system("cls");
    cout << "Seguro que deseas salir del programa?\t1.Si\t2.Noo" << endl;
    cout << "-> ";
    cin >> eleccion;

    if (eleccion == 1){
        cout << "Gracias por utilizar mi programa!" << endl;
        return;
    }
    else if (eleccion == 2){
        Menu_principal();
    } else {
        cout << "Ingrese un digito valido." << endl;
        system("pause");
        Salir();
    }
}

bool Menu::Validacion(){
    return band == false;
}

void Menu::Mostrar_lista(){
        system("cls");
        cout << "\t---Lista---" << endl;
        l->Mostrar_todo();
        return;
}

bool Menu::ValidacionDato(Alumno* alumno){ //Si alumno no existe devuelve true.
    return alumno == nullptr;
}

void Menu::Formato_alumno(){
    system("cls");
    cout << "Indique el formato en el que va ingresar los datos:" << endl;
    cout << "1. Solo nombre" << endl;
    cout << "2. Nombre, edad y promedio" << endl;
    cout << "3. Formato completo" << endl;
    cout << "-> ";
    cin >> eleccion;

    switch (eleccion){
    case 1:
        cout << "\n\n" << "******************************************" << endl;
        cout << "Ingresa el nombre: ";
        cin.ignore();
        getline(cin, nombre);

        nombre = ValidarString(nombre);

        dato = new Alumno(nombre);
        if (ValidacionDato(dato)){ //Valida si se asigno el espacio en memoria
            cout << "Espacio en la memoria no asignado. Intentenuevamente" << endl;
        }

        cout << "******************************************" << "\n\n";
        break;
    case 2:
        cout << "\n\n" << "******************************************" << endl;
        cout << "Ingresa el nombre: ";
        cin.ignore();
        getline(cin, nombre);
        cout << "Ingresa la edad: ";
        cin >> edad;
        cout << "Ingresa el promedio: ";
        cin >> promedio;

        nombre = ValidarString(nombre);

        dato = new Alumno(nombre,edad,promedio);
        if (ValidacionDato(dato)){ //Valida si se asigno el espacio en memoria
            cout << "Espacio en la memoria no asignado. Intentenuevamente" << endl;
        }

        cout << "******************************************" << "\n\n";
        break;
    case 3:
        cout << "\n\n" << "******************************************" << endl;
        cout << "Ingresa el nombre: ";
        cin.ignore();
        getline(cin, nombre);
        cout << "Ingresa la edad: ";
        cin >> edad;
        cout << "Ingresa la carrera: ";
        cin.ignore();
        getline(cin, carrera);
        cout << "Ingresa el promedio: ";
        cin >> promedio;
        cout << "Ingresa el codigo de la udg: ";
        cin.ignore();
        getline(cin, codigo);


        nombre = ValidarString(nombre);
        carrera = ValidarString(carrera);
        codigo = ValidarString(codigo);


        dato = new Alumno(nombre,edad,carrera,promedio,codigo);
        if (ValidacionDato(dato)){ //Valida si se asigno el espacio en memoria
            cout << "Espacio en la memoria no asignado. Intentenuevamente" << endl;
        }

        cout << "******************************************" << "\n\n";
        break;
    default:
        cout << "Ingrese un digito valido." << endl;
        system("pause");
        Formato_alumno();
        break;
    }

    return;
}

void Menu::Formato_buscar(){
    cout << "Seleccione por que rasgo buscar en el siguiente menu: " << endl;
    cout << "1.Posicion." << endl;
    cout << "2.Nombre (Toma la primer incidencia)." << endl;
    cout << "3.Nombre y codigo (mas seguro)." << endl;
    cout << "-> ";
    cin >> eleccion;

    switch (eleccion){
    case 1:
        cout << "Ingrese la posicion: ";
        cin >> posicion;
        l->Buscar(posicion,nombre,codigo,POSICION);
        break;
    case 2:
        cout << "Ingrese el nombre del alumno: ";
        cin.ignore();
        getline(cin, nombre);
        l->Buscar(posicion,nombre,codigo,NOMBRE);
        break;
    case 3:
        cout << "Ingrese el nombre del alumno: ";
        cin.ignore();
        getline(cin, nombre);
        cout << "Ingrese el codigo del alumno: ";
        cin >> codigo;
        l->Buscar(posicion,nombre,codigo,NOMYCOD);
        break;
    default:
        cout << "Ingrese un digito valido." << endl;
        system("pause");
        Formato_buscar();
        break;
    }
}

string Menu::ValidarString(string nacada){
    if (nacada.empty()) {
        return "Desconocido";
    } else {
        return nacada;
    }
}


Menu::Menu()
{
    eleccion = 0;
    band = false;
    dato = nullptr;
    posicion = 0;
    centinela = true;
}

Menu::~Menu()
{

}

