#include "Lista.h"
#include <iostream>
using namespace std;

Lista::Lista()
{
    cabeza = nullptr;
}

Lista::~Lista()
{
    Eliminar_Todo();
}


    /*Funciones de insertar*/

void Lista::Insert_inicio(Alumno* dato){
    Nodo* aux;
    aux = new Nodo(dato,cabeza);
    cabeza = aux;
    if (aux){
        cout << "Alumno '" << dato->Get_nombre() << "' insertado al inicio!" << endl;  //Informa si el nodo fue creado correctamente
    } else {
        cout << "ERROR: falla en la asignacion de memoria" << endl;
    }
}

void Lista::Insert_final(Alumno* dato){
    Nodo *aux, *ultimo;
    aux = new Nodo(dato);

    if (cabeza){    //Despu�s de crearse el nodo, checa si existe una lista y busca el final de la lista.
        ultimo = cabeza;
        while (ultimo->ptr)
            ultimo = ultimo->ptr;
        ultimo->ptr = aux;
    } else
        cabeza = aux;
    if (aux){
        cout << "Alumno '" << dato->Get_nombre() << "' insertado al final!" << endl;  //Informa si el nodo fue creado correctamente
    } else {
        cout << "ERROR: falla en la asignacion de memoria" << endl;
    }
}

void Lista::Insertar_posicion(int posicion, Alumno* dato){
    Nodo* aux;
    aux = cabeza;

    if (Vacio()){ // Comprueba si la lista esta vacia, si es as�, inserta el dato al inicio.
        cout << "Esta lista actualmente se encuentra vacia: Se creara la lista y el alumno '" << dato->Get_nombre() <<"' se insertara en la primera posicion." << endl;
        Insert_inicio(dato);
    }
    else if(posicion >= Tamanio() + 1){ //Si la posicion es mayor, inserta el dato al final.
        Insert_final(dato);
    }
    else if (posicion == 1){ //Si la posicion es 1, inserta al inicio
        Insert_inicio(dato);
    }
    else {  //Inserta nodo en la posicion indicada
        int i;
        Nodo *nueva_posicion = nullptr, *temp = nullptr; //temp crea el nuevo nodo, nueva posicion, guarda el nodo anterior.
        for (i = 1; i < posicion; i++)
            aux = aux->ptr;
        nueva_posicion = Anterior(aux);
        temp = new Nodo(dato,aux);
        nueva_posicion->ptr = temp;
        cout << "Alumno '" << dato->Get_nombre() << "' correctamente insertado en la posicion: " << posicion << endl;
    }

    return;
}

    /*Funciones de Mostrar*/

void Lista::Mostrar_todo(){
    if (Vacio()){
        cout << "Esta lista actualmente se encuentra vacia: no hay nada por mostrar." << endl;
    } else {
        Nodo* aux;
        aux = cabeza;
        int i = 1;
        while (aux){
            cout << "Posicion: " << i << endl;
            MostrarAlumno(aux);
            aux = aux->ptr;
            i++;
        }
    }
}

bool Lista::Vacio(){
    return cabeza == nullptr;
}

int Lista::Tamanio(){
    int tamanio = 0;
    Nodo* aux = cabeza;

    while (aux){
        tamanio++;
        aux = aux->ptr;
    }
    return tamanio;
}

bool Lista::Validar_posicion(int posicion){
    return posicion > 0;
}

void Lista::Mostrar_enPosicion(Nodo* direccion){
    if (direccion == nullptr){
        cout << "Direccion apuntando a nulo, ingrese una direccion valida. Puede ultilizar la funcion mostrar todo si desea verificar informacion de esta lista." << endl;
    }
    else {
        MostrarAlumno(direccion);
    }
    return;
}

    /*Funciones de buscar*/

Nodo* Lista::Buscar(int posicion,string nombre, string codigo, int metodo){
    if (Vacio()){
        cout << "Esta lista actualmente se encuentra vacia, verifica si buscabas en otra lista." << endl;
    } else {
        Nodo* aux;
        aux = cabeza;
        int i;

        switch (metodo){
        case 1:     // Primer m�todo para solo buscar por posici�n.

            if (Validar_posicion(posicion)){
                for (i = 1; i < posicion && aux->ptr; i++)
                    aux = aux->ptr;
                if (i == posicion){
                    cout << "Alumno encontrado: \n";
                    MostrarAlumno(aux);
                    return aux;
                } else if (posicion > i){ // Indica si la posicion ingresada es un numero mayor a la cantidad de elmentos que hay en la lista.
                    cout << "La posicion es mayor al numero de elementos actuales de esta lista." << endl;
                    return nullptr;
                }
            } else {
                cout << "Posicion NO valida, ingreso un entero no negativo." << endl;
                return nullptr;
            }
            break;

        case 2:     // Segundo m�todo para buscar solo por nombre (regresa la direccion de la primer coincidencia).

            i = 1;

            while (nombre != aux->info->Get_nombre() && aux->ptr){
                aux = aux->ptr;
                i++;
            }
            if (nombre == aux->info->Get_nombre()){
                cout << "Alumno '" << nombre << "' encontrado en la posicion: " << i << endl;
                return aux;
            } else {
                cout << "El alumno no se encuentra inscrito en esta lista" << endl;
                return nullptr;
            }
            break;

        case 3:     // Tercer m�todo para buscar por nombre y c�digo.
            i = 1;
            while (aux->ptr && nombre != aux->info->Get_nombre() && codigo == aux->info->Get_codigo()){
                aux = aux->ptr;
                i++;
            }
            if (nombre == aux->info->Get_nombre() && codigo == aux->info->Get_codigo()){
                cout << "Alumno '" << nombre << "' encontrado en la posicion: " << i << endl;
                return aux;
            } else {
                cout << "El alumno no se encuentra inscrito en esta lista" << endl;
                return nullptr;
            }


        default:
            cout << "Metodo ingresado no valido, en el apartado de metodos de busqueda ingrese: 1)Buscar por posicion\t 2)Buscar por dato" << endl;
            return nullptr;
            break;
        }
    }
    return nullptr;
}

Nodo* Lista::Primero(){
    if (Vacio())
        cout << "Esta lista actualmente se encuentra vacia." << endl;
    else {
        return cabeza;
    }
    return nullptr;
}

Nodo* Lista::Ultimo(){
    if (Vacio())
        cout << "Esta lista actualmente se encuentra vacia." << endl;
    else {
        Nodo* aux;
        aux = cabeza;
        while (aux->ptr){
            aux = aux->ptr;
        }
        return aux;
    }
    return nullptr;
}

Nodo* Lista::Siguiente(Nodo* actual){
    if (Vacio())
        cout << "Esta lista actualmente se encuentra vacia." << endl;
    else if (actual->ptr == nullptr){
        cout << "No existe ningun elemento posterior al indicado, en esta lista." << endl;
        return nullptr;
    }
    else {
        return actual->ptr;
    }
    return nullptr;
}

Nodo* Lista::Anterior(Nodo* actual){
    if (Vacio()){
        cout << "Esta lista actualmente esta vacia." << endl;
        return nullptr;
    }
    else if (cabeza == actual){
        cout << "No existe ningun elemento anterior al indicado, en esta lista." << endl;
        return nullptr;
    }
    else if (actual == nullptr){
        cout << "La direccion ingresada apunta a nulo. Ingrese otra direccion." << endl;
        return nullptr;
    }
    else {
        Nodo* aux;
        aux = cabeza;
        while (aux->ptr != actual && aux->ptr)
            aux = aux->ptr;
        if (aux->ptr == actual){
            return aux;
        }
        else {
            cout << "No existe ningun elemento anterior al indicado, en esta lista." << endl;
            return nullptr;
        }
    }
    return nullptr;
}

    /*Funciones de eliminar*/

void Lista::Eliminar(int posicion){
    if (Vacio()) {
        cout << "Lista vacia" << endl;
        return;
    } else if (Buscar(posicion, " ", " ", BUSCAR_POSICION) == nullptr){
        cout << "No existe un elemento en la posicion" << endl;
        return;
    } else if (posicion == 1 && Tamanio() == 1){
        Nodo* aux;
        aux = cabeza;

        cabeza = nullptr;
        delete aux;
        aux = nullptr;
        cout << "Elemento eliminado!" << endl;
        return;
    } else if (posicion == 1){

        Nodo* aux;
        aux = cabeza;

        cabeza = cabeza->ptr;
        delete aux;
        aux = nullptr;
        cout << "Elemento eliminado!" << endl;
        return;
    } else {
        Nodo *aux, *auxR;
        aux = cabeza;
        auxR = nullptr;
        int i;
        for (i = 1; i < posicion; i++)
            aux = aux->ptr;
        auxR = Anterior(aux);
        auxR->ptr = aux->ptr;
        delete aux;
        aux = nullptr;
        cout << "Elemento eliminado con exito!" << endl;
        return;
    }
}


void Lista::Eliminar_Todo(){
    if (Vacio()){
        cout << "No existe ninguna lista, nada por eliminar." << endl;
    } else {
        Nodo *aux, *auxR;
        aux = cabeza;
        auxR = nullptr;
        cabeza = nullptr;

        while (aux){
            auxR = aux;
            aux = aux->ptr;
            delete auxR;
        }

        cout << "Esta lista ha sido borrada exitosamente!" << endl;
    }
    return;
}

void Lista::MostrarAlumno(Nodo* aux){
    cout << "---------------------------" << endl;
    cout << "Nombre: " << aux->info->Get_nombre() << endl;
    cout << "Edad: " << aux->info->Get_edad() << endl;
    cout << "Carrera: " << aux->info->Get_carrera() << endl;
    cout << "Promedio: " << aux->info->Get_promedio() << endl;
    cout << "Codigo: " << aux->info->Get_codigo() << endl;
    cout << "---------------------------" << "\n\n";
    return;
}
