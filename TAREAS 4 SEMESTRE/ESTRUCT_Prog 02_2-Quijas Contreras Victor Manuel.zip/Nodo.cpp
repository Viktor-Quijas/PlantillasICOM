#include "Nodo.h"
#include <iostream>
using namespace std;

Nodo::Nodo()
{
    info = nullptr;
    ptr = nullptr;
}

Nodo::Nodo(Alumno* info){
    this->info = info;
    ptr = nullptr;
}

Nodo::Nodo(Alumno* info,Nodo* ptr){
    this->info = info;
    this->ptr = ptr;
}

Nodo::~Nodo()
{
    delete info;
}
