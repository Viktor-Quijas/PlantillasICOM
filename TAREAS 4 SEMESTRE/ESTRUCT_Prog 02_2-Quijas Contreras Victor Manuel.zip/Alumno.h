#ifndef ALUMNO_H
#define ALUMNO_H

#include <iostream>
#include <string>
using namespace std;

class Alumno {
public:
    // SETTERS
    void Set_nombre(string newnombre);
    void Set_edad(int newedad);
    void Set_carrera(string newcarrera);
    void Set_promedio(float newpromedio);
    void Set_codigo(string newcodigo);

    // GETTERS
    string Get_nombre();
    int Get_edad();
    string Get_carrera();
    float Get_promedio();
    string Get_codigo();

    // Constructores
    Alumno(); // por defecto
    Alumno( string nombre); // solo nombre
    Alumno( string nombre, int edad, float promedio); // nombre, edad, promedio
    Alumno( string nombre, int edad, string carrera, float promedio, string codigo); // completo

    ~Alumno();

private:
    string nombre;
    int edad;
    string carrera;
    float promedio;
    string codigo;
};

#endif // ALUMNO_H

