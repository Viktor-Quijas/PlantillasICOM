#ifndef MENU_H
#define MENU_H
#include "Lista.h"


class Menu
{
    public:
        Lista* l;

        void Menu_principal();
        bool Validacion();
        bool ValidacionDato(Alumno* alumno);
        void Salir();

        int eleccion;
        bool band;
        bool centinela;
        Alumno* dato;
        int posicion;

        /*Datos para alumno*/
        string nombre;
        string carrera;
        string codigo;
        int edad;
        float promedio;

        /*Menu para cada accion*/
        void Inicializar_lista();
        void Insertar_elemento();
        void Mostrar_lista();
        void Buscar_elemento();
        void Eliminar_elemento();
        void Eliminar_lista();


        /*Obtener datos para alumno*/
        void Formato_alumno();
        void Formato_buscar();
        string ValidarString(string nacada);


        Menu();
        ~Menu();

    protected:

    private:
};

#endif // MENU_H

