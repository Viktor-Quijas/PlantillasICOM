#include "Alumno.h"
#include <iostream>
using namespace std;

        /* Mensajes de advertencia */
#define VACIO "No se registro ningun dato en la variable"
#define EDAD "Edad invalida (1..125)."
#define PROMEDIO "Promedio invalido (0..100)."
#define CODIGO "El codigo UDG debe tener 9 digitos. EJEMPLO: '123456789'"

        /* SETTERS */

void Alumno::Set_nombre(string newnombre) {
    if (newnombre.empty()) {
        cout << "ADVERTENCIA: " << VACIO << endl;
        nombre = "Desconocido";
    } else {
        nombre = newnombre;
    }
}

void Alumno::Set_edad(int newedad) {
    if (newedad < 1 || newedad > 125) {
        cout << "ADVERTENCIA: " << EDAD << endl;
        edad = 0;
    } else {
        edad = newedad;
    }
}

void Alumno::Set_carrera(string newcarrera) {
    if (newcarrera.empty()) {
        cout << "ADVERTENCIA: " << VACIO << endl;
        carrera = "Desconocido";
    } else {
        carrera = newcarrera;
    }
}

void Alumno::Set_promedio(float newpromedio) {
    if (newpromedio < 0 || newpromedio > 100) {
        cout << "ADVERTENCIA: " << PROMEDIO << endl;
        promedio = 0;
    } else {
        promedio = newpromedio;
    }
}

void Alumno::Set_codigo(string newcodigo) {
    if (newcodigo.empty()) {
        cout << "ADVERTENCIA: " << VACIO << endl;
        codigo = "Desconocido";
    } else if (newcodigo.length() != 9) {
        cout << "ADVERTENCIA: " << CODIGO << endl;
        codigo = "000000000";
    } else {
        codigo = newcodigo;
    }
}

        /* GETTERS */

string Alumno::Get_nombre() { return nombre; }
int Alumno::Get_edad() { return edad; }
string Alumno::Get_carrera() { return carrera; }
float Alumno::Get_promedio() { return promedio; }
string Alumno::Get_codigo() { return codigo; }

        /* Constructores */

Alumno::Alumno() {
    nombre = "Desconocido";
    edad = 0;
    carrera = "Desconocido";
    promedio = 0;
    codigo = "000000000";
}

Alumno::Alumno(string nombre) {
    Set_nombre(nombre);
    edad = 0;
    carrera = "Desconocido";
    promedio = 0;
    codigo = "000000000";
}

Alumno::Alumno(string nombre, int edad, float promedio) {
    Set_nombre(nombre);
    Set_edad(edad);
    Set_promedio(promedio);
    carrera = "Desconocido";
    codigo = "000000000";
}

Alumno::Alumno(string nombre, int edad, string carrera, float promedio, string codigo) {
    Set_nombre(nombre);
    Set_edad(edad);
    Set_carrera(carrera);
    Set_promedio(promedio);
    Set_codigo(codigo);
}

Alumno::~Alumno() {

}

