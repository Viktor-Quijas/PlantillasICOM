package lote;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class TablaTerminados extends JFrame{
	private static final long serialVersionUID = 1L;
	
	private JTable tablaTerminados;
	private DefaultTableModel modelo;
	
	private int operacion;
	
	public TablaTerminados(Frame tabla) {
		setTitle("Procesos Terminados");
		setSize(1250,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(tabla);
		
		String[] columnas = {"ID", "Ope", "Res", "Tiempo de Llegada", "Tiempo de Finalización", "Tiempo de Retorno", "Tiempo de Respuesta", "Tiempo de Espera", "Tiempo de Servicio"};
		modelo = new DefaultTableModel(null, columnas);
		
		tablaTerminados = new JTable(modelo);
		
		add(new JScrollPane(tablaTerminados), BorderLayout.CENTER);
	}
	
	public void AgregarATablaTerminados(Proceso p) {
		if (!p.getError()) {
			operacion = p.getOperacion();
			switch (operacion) {
			case 0:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " + " + p.getY(), 
						p.getResultado(),
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoMax()});
				break;
			case 1:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " - " + p.getY(), 
						p.getResultado(),
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoMax()});		
				break;
			case 2:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " * " + p.getY(), 
						p.getResultado(),
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoMax()});		
				break;
			case 3:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " / " + p.getY(), 
						p.getResultado(),
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoMax()});		
				break;
			case 4:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " ^ " + p.getY(), 
						p.getResultado(),
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoMax()});		
				break;
			case 5:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " % " + p.getY(), 
						p.getResultado(),
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoMax()});		
				break;
			}
		} else {
			operacion = p.getOperacion();
			switch (operacion) {
			case 0:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " + " + p.getY(), 
						"ERROR",
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoTranscurrido()});
				break;
			case 1:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " - " + p.getY(), 
						"ERROR",
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoTranscurrido()});		
				break;
			case 2:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " * " + p.getY(), 
						"ERROR",
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoTranscurrido()});			
				break;
			case 3:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " / " + p.getY(), 
						"ERROR",
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoTranscurrido()});		
				break;
			case 4:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " ^ " + p.getY(), 
						"ERROR",
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoTranscurrido()});			
				break;
			case 5:
				modelo.addRow(new Object[] {p.getId(), 
						p.getX() + " % " + p.getY(), 
						"ERROR",
						p.getTiempoLlegada(),
						p.getTiempoFinalizacion(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada(),
						p.getTiempoRespuesta(),
						p.getTiempoFinalizacion() - p.getTiempoLlegada() - p.getTiempoTranscurrido(),
						p.getTiempoTranscurrido()});		
				break;
			}
		}
	}
	
}
